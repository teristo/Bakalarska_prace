﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace YearProject
{
    /// <summary>
    /// Class to represent common colors and other drawing properties which are used by various components. 
    /// </summary>
    public class GraphicsSchema
    {
        public Brush ColorOfGraph { get; } = Brushes.Salmon;
        public Brush ColorOfActiveNode { get; } = Brushes.DarkRed;
        public Brush StringBrush { get; } = Brushes.Black;
        public Pen JoinedWordCircumference { get; } = Pens.DarkRed;
        public Pen OmittedWordCircumference { get; } = Pens.DarkBlue;
        public Font BoldFont { get; } = new Font("Arial", 10, FontStyle.Bold);
        public Size sizeOfPoint { get; } = new Size(15, 15);
    }

    /// <summary>
    /// Class to visualise the graph of sentence with use of the concrete designer and according to the size of the form.
    /// Implements IVisualiser interface.
    /// </summary>
    public class Visualiser : IVisualiser
    {
        /// <summary>
        /// The size of the point in the graph. Same as in the graphics schema.
        /// </summary>
        public Size sizeOfPoint { get { return Schema.sizeOfPoint; } }
        /// <summary>
        /// Current sroll position of TreePanel, where the sentence is visualised.
        /// </summary>
        /// <seealso cref="TreePanel"/>
        public PointF scrollPosition { get; protected set; }
        /// <summary>
        /// Used graphics schema - colors, font, size of point. S
        /// Same for all components which participate in graph visualisation.
        /// </summary>
        private GraphicsSchema Schema { get; } = new GraphicsSchema();
        /// <summary>
        /// The half of the space which rests in the TreePanel after counting the graph width.
        /// </summary>
        private float leftSpace { get; set; } = 0;
        /// <summary>
        /// The height of each floor of the graph.
        /// </summary>
        private float levelDifference { get; set; }
        /// <summary>
        /// The count of floors in the graph.
        /// </summary>
        private int maximumHeight { get; set; } = 1;
        /// <summary>
        /// Created graphics of the TreePanel.
        /// </summary>
        /// <seealso cref="TreePanel"/>
        private Graphics graphics { get; set; }
        /// <summary>
        /// The constant that determines the minimum height of floor.
        /// </summary>
        private const int minLevelDiff = 10;
        /// <summary>
        /// The constant that determines the minimal space between two words.
        /// </summary>
        private const float minSpace = 10;
        /// <summary>
        /// The constant that determines the margin of TreePanel, which must be left empty.
        /// </summary>
        private const int margin = 50;
        /// <summary>
        /// The panel in the main form, where the graph of the active sentence is drawn.
        /// </summary>
        private Panel TreePanel;
        /// <summary>
        /// The counted x-coordinates of word points in the sentence. 
        /// Key Value pairs means the word Ids and its starting place according to the width of the preceding words.
        /// </summary>
        private Dictionary<string, float> StartsOfWords;
        /// <summary>
        /// The set of IVisitors that allow different word rendering based on the word type and current representation.
        /// </summary>
        private IDesigner designer;
        /// <summary>
        /// Creates a new visualiser which will use <paramref name="designer"/> to represent sentence on the <paramref name="treePanel"/>
        /// </summary>
        /// <param name="treePanel"> </param>
        /// <param name="designer">The designer which will be used to draw the sentence graph according to representation.</param>
        public Visualiser(Panel treePanel, IDesigner designer)
        {
            // Initializes the designer according to the representation and given schema
            designer.CreateVisitors(Schema);
            this.designer = designer;
            TreePanel = treePanel;
            scrollPosition = treePanel.AutoScrollPosition;
            graphics = treePanel.CreateGraphics();
        }
        
        /// <summary>
        /// Writes the Form word attribute under each word point in the sentence.
        /// </summary>
        /// <param name="sentence">The visualised sentence.</param>
        private void WriteStrings(ISentence sentence)
        {
            // For all words in the sentence
            for (int i = 0; i < sentence.CountWords; i++)
            {
                // Gets word according to its position in the sentence
                IWord word = sentence.GetWord(i);
                // Visits the concrete word and according to its type writes the Form attribute under the point.
                // In some cases does not do anything.
                word.Accept(designer.WriteWord, graphics, word.GetPoint().X, word.GetPoint().Y + Schema.sizeOfPoint.Height);
            }
        }

        /// <summary>
        /// Visualises the whole sentence. Uses concrete designer to visualise the concrete representation.
        /// </summary>
        /// <param name="sentence">The sentence which is going to be visualsised.</param>
        public void Visualise(ISentence sentence)
        {
            // Each sentence must have a root
            if (sentence == null || sentence.Root == null)
                return;
            // Root point x-coordinate is in the middle of the width of the tree panel.
            // Root point y-coordinate is the same as the minimal distance of two neighbouring graph floors.
            sentence.Root.SetPoint(new PointF(TreePanel.Width / 2f - Schema.sizeOfPoint.Width / 2f, minLevelDiff));
            // Draws the root point according to representation
            sentence.Root.Accept(designer.DrawWord, graphics);
            // For all words except from the root, finishes making of the point and draws the word.
            for (int i = 1; i < sentence.CountWords; i++)
            {
                // Gets the word according to position in the sentence.
                IWord word = sentence.GetWord(i);
                // Visits the concrete word and according to its type and representation draws the word or does not do anything.
                word.Accept(designer.DrawWord, graphics, GetPoint(word));
            }
            // Writes all words under their points
            WriteStrings(sentence);
        }

        /// <summary>
        /// Prepares the graphics of the <seealso cref="TreePanel"/>.
        /// </summary>
        /// <param name="graphWidth">The width of th whole sentence graph. If it is 0, no the size is not changed.</param>
        private void PrepareNewGraphics(int graphWidth)
        {
            // Graph width must be greather than 0.
            if (graphWidth <= 0)
                graphWidth = TreePanel.AutoScrollMinSize.Width;
            // Height is the sum of all the spaces between the levels and the margin.
            int needHeight = (maximumHeight - 1) * (int)levelDifference + margin;
            // It is necessary to edit the minimum scroll size in the TreePanel
            TreePanel.AutoScrollMinSize = new Size(graphWidth, needHeight);
            // We need to create the new graphics
            Graphics gNew = TreePanel.CreateGraphics();
            gNew.TranslateTransform(TreePanel.AutoScrollPosition.X, TreePanel.AutoScrollPosition.Y);
            gNew.Clear(Color.White);
            graphics = gNew;
        }
        
        /// <summary>
        /// Counts x and y coordinates of all the words in the sentence.
        /// </summary>
        /// <param name="sentence">The visualised sentence.</param>
        /// <returns>The final width of the graph.</returns>
        private float CountCoordinates(ISentence sentence)
        {
            // Prepares x-coordinates of all the words.
            float graphWidth = prepareXes(sentence);
            maximumHeight = 1;
            // Counts the levels in which the words will be visualised in the graph.
            HeightOfSubtrees(sentence.Root, 1);
            //Space which remains for each level in the graph view. 
            // If the graph is too tall, the minimum spaces are used and the vertical scrollbar will appear.
            levelDifference = (TreePanel.Height - minLevelDiff - margin) / (Math.Max(maximumHeight-1, 1));
            if (levelDifference < Schema.sizeOfPoint.Height + Schema.BoldFont.Height + minLevelDiff)
                levelDifference = Schema.sizeOfPoint.Height + Schema.BoldFont.Height + minLevelDiff;
            // Space which rests on the left side of the graph if the graph in case of the thin graph.
            // Graph is situated in the middle of the panel.
            // If the graph is too wide, the left space is 0.
            leftSpace = (TreePanel.Width - graphWidth) / 2;
            if (leftSpace < 0) leftSpace = 0;
            return graphWidth;
        }

        /// <summary>
        /// Method used to count new coordinates of the words and to visualise the sentence.
        /// </summary>
        /// <param name="sentence">The sentence which is going to be visualised.</param>
        public void NewGraphics(ISentence sentence)
        {
            // Graph width is allways a positive number.
            float graphWidth = CountCoordinates(sentence);
            // Prepares the empty graphics and translate it according to the AutoScroll position
            PrepareNewGraphics((int)graphWidth);
            // Prepares the information to find out the x and y coordinates of all words
            PreparePoints(sentence);
            // Visualises the whole graph
            Visualise(sentence);
            scrollPosition = TreePanel.AutoScrollPosition;
        }

        /// <summary>
        /// Method used mainly while scrolling the existing graph. The point positions are not counted again.
        /// </summary>
        /// <param name="sentence">The sentence whose graph is going to be scrolled.</param>
        public void ScrollNewGraphics(ISentence sentence )
        {
            // Prepares the empty graphics and translate it according to the AutoScroll position
            // If the graphWidth argument is 0, the size of the drawing space will not change
            PrepareNewGraphics(0);
            // Visualises the whole graph
            Visualise(sentence);
            scrollPosition = TreePanel.AutoScrollPosition;
        }

        /// <summary>
        /// Counts the graph levels of the words in the sentence
        /// </summary>
        /// <param name="subRoot">The root of the subtree.</param>
        /// <param name="actualLevel">The level of the root of the subtree.</param>
        private void HeightOfSubtrees(IWord subRoot, int actualLevel)
        {
            // Saves the root Level
            subRoot.Level = actualLevel;
            // All children will have the same lavel as their parent plus one
            foreach (IWord child in subRoot.Children.Values)
            {
                HeightOfSubtrees(child, actualLevel + 1);
            }
            // We test if this level is the maximum in the found levels.
            if (actualLevel > maximumHeight)
            {
                maximumHeight = actualLevel;
            }
        }

        /// <summary>
        /// Counts the starting positions of all words in the sentence and saves the results into the <seealso cref="StartsOfWords"/>.
        /// </summary>
        /// <param name="sentence">The sentence whose graph is going to be visualised.</param>
        /// <returns>The final width of the graph.</returns>
        private float prepareXes(ISentence sentence)
        {
            // Initialize the dictionary. The initializing word will start in 0.
            StartsOfWords = new Dictionary<string, float>();
            StartsOfWords["0"] = 0;
            IWord lastWord = sentence.Root;
            for (int i = 1; i < sentence.CountWords; i++)
            {
                IWord word = sentence.GetWord(i);
                // Saves the start of the word according to the end of the preceding word
                SaveStartOfWord(word.Id, lastWord);
                // This word will be the preceding in the next iteration
                lastWord = word;
            }
            // To find out the final graph width, we will add the extra word. 
            // The position where the next word would start is the graph width.
            string extra_ID = "EXTRA";
            SaveStartOfWord(extra_ID, lastWord);
            // Never returns 0, if there is at least one visualised word (the root is in each sentence).
            return StartsOfWords[extra_ID];
        }

        /// <summary>
        /// Saves the start of the word to  <seealso cref="StartsOfWords"/> according to the preceding word. 
        /// </summary>
        /// <param name="id">Id of the current word</param>
        /// <param name="preceding">The preceding word</param>
        private void SaveStartOfWord(string id, IWord preceding)
        {
            // Gets the form size according to the representation and the word type
            // If the word should not be visualised, the returned value is 0.
            float form_size = ((SizeF)preceding.Accept(designer.FormSize, graphics, Schema.BoldFont)).Width;
            StartsOfWords[id] = StartsOfWords[preceding.Id] + form_size;
            // If the word should be visualised, we add the space between the words.
            if (form_size != 0)
                StartsOfWords[id] += minSpace;
        }

        /// <summary>
        /// Method which counts the points of all words and saves them the point to the property <see cref="Word.GetPoint()"/>.
        /// If the word is not visualised in the current representation, its point is set to default.
        /// </summary>
        /// <param name="sentence">The sentence whose word points are counted.</param>
        private void PreparePoints(ISentence sentence)
        {
            IWord last = sentence.Root;
            // Saves the points to all visualised words
            for (int i = 1; i < sentence.CountWords; i++)
            {
                IWord word = sentence.GetWord(i);
                // If the x-coordinates are identical, the last point was not visualised. Its point is set to be empty.
                if (StartsOfWords[word.Id] == StartsOfWords[last.Id])
                    last.SetPoint(new PointF());
                word.SetPoint(GetPoint(word));
                last = word;
            }
        }

        /// <summary>
        /// Counts the coordinates of the word point according to prepared 
        /// <seealso cref="StartsOfWords"/>, <seealso cref="levelDifference"/> and <seealso cref="leftSpace"/>
        /// </summary>
        /// <param name="word">The word whose point is counted</param>
        /// <returns></returns>
        private PointF GetPoint(IWord word)
        {
            // Add left space to the counted start to shift the graph to the middle
            float x = StartsOfWords[word.Id] + leftSpace;
            float y = levelDifference * (word.Level - 1) + minLevelDiff;
            return new PointF(x, y);
        }
        
        /// <summary>
        /// Method used to draw only one word point without revisualising all the graph.
        /// </summary>
        /// <param name="word">The word whose pint will be drawn.</param>
        public void DrawOneWord(IWord word)
        {
            // The deleted word id is set to null, will not be visualised.
            if (word.Id == null)
                return;
            // Draws the point of the word according to the representation and the type of the word.
            word.Accept(designer.DrawPoint, graphics);
        }

        /// <summary>
        /// Modifies the <paramref name="basicWordInfo"/> so thai it contains the basic information about the word or sentence.
        /// </summary>
        /// <param name="basicWordInfo">
        /// The panel, on which the basic information are written. Should have at least 3 controls.
        /// </param>
        /// <param name="word">The word whose information are shown</param>
        /// <param name="sentence">In the case the word is root, the sent_id is shown instead of the word info.</param>
        /// <returns>true if the info was made visible; otherwise, false</returns>
        public bool ShowBasicInfo(Panel basicWordInfo, IWord word, ISentence sentence)
        {
            // Sent to the Basic info creator the borders which the panel with info can not intersect
            return BasicInfo(word, word.GetWordBasicInfo(sentence.Sent_id), basicWordInfo, graphics, 
                TreePanel.Height - margin, TreePanel.Width - margin, TreePanel.AutoScrollPosition);
        }

        /// <summary>
        /// The method modifies <paramref name="basicWordInfo"/> by the information from <paramref name="values"/>.
        /// It counts the good position of the panel.
        /// </summary>
        /// <param name="word">The word on whose point the panel will be positioned</param>
        /// <param name="values">The array of the values which should be visualised in the panel</param>
        /// <param name="basicWordInfo">The panel which is modified and set to be visible</param>
        /// <param name="g">The graphics where we measure the width of the values in the array</param>
        /// <param name="heightForm">The height of the drawing space, the panel must end above</param>
        /// <param name="widthForm">The width of the drawing space, the panel can not intersect it</param>
        /// <param name="scroll">The actual scroll position of the drawing space</param>
        /// <returns>true if the info was made visible; otherwise, false</returns>
        private bool BasicInfo(IWord word, string[] values, Panel basicWordInfo, Graphics g, float heightForm, float widthForm, PointF scroll)
        {
            // There must be at least one value to show
            if (values.Length == 0) return false;
            // We must find out the width and the height of the panel
            float maxWidth = values.Max(x => g.MeasureString(x, Schema.BoldFont).Width);
            float maxHeight = g.MeasureString(values[0], Schema.BoldFont).Height;
            // We try to set the starting coordinates to the right down corner of the word point
            float startX = word.GetPoint().X + Schema.sizeOfPoint.Width + scroll.X;
            float startY = word.GetPoint().Y + Schema.sizeOfPoint.Height + scroll.Y;
            // We shift the starting coordinates so that the panel can fit into the view
            if (startY + Schema.sizeOfPoint.Height + (values.Length * maxHeight) > heightForm)
            {
                startY = word.GetPoint().Y + scroll.Y - (maxHeight * values.Length);
            }
            if (startX + maxWidth > widthForm)
            {
                startX = Math.Max(0, word.GetPoint().X + scroll.X - maxWidth);
            }
            basicWordInfo.Location = new Point((int)startX, (int)startY);
            // All values in the array are visualised (if there are enough controls in the panel)
            int i;
            for (i = 0; i < values.Length; i++)
            {
                if (basicWordInfo.Controls.Count <= i)
                    break;
                basicWordInfo.Controls[i].Text = values[i];
                basicWordInfo.Controls[i].Visible = true;
            }
            // All remaining controls are hidden
            for (int j = i; i < basicWordInfo.Controls.Count; ++i)
            {
                basicWordInfo.Controls[i].Visible = false;
            }
            basicWordInfo.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            basicWordInfo.AutoSize = true;
            basicWordInfo.Visible = true;
            return true;
        }

        /// <summary>
        /// Gets the position inside the drawing space.
        /// Returns the word whose drawn point contains the received position (or null) 
        /// </summary>
        /// <param name="sentence">Sentence in which the word is searched</param>
        /// <param name="origPoint">The point inside the drawing space</param>
        /// <returns>The word, whose drawn point contains the received position, null if no word point contains it.</returns>
        public IWord FindRightPoint(ISentence sentence, PointF origPoint)
        {
            // Changes the point according to current scroll position
            PointF point = new PointF(origPoint.X - TreePanel.AutoScrollPosition.X, origPoint.Y - TreePanel.AutoScrollPosition.Y);
            for (int i = 0; i < sentence.CountWords; i++)
            {
                IWord word = sentence.GetWord(i);
                // Returns exactly the information that we need - true if the point is inside word point
                if (word.MatchPoint(point, sizeOfPoint))
                    return word;
            }
            return null;
        }

        /// <summary>
        /// Gets the active word and tries to shift from it in the given direction (<paramref name="key"/>) in the tree.
        /// If the shift fails, returns the current active word.
        /// </summary>
        /// <param name="key">The arrow key, specifies the direction of shift</param>
        /// <param name="active">Current active word</param>
        /// <returns>
        /// The word to where the activity moved. 
        /// If the shift failed, returns the original active word.
        /// If the original ward is deleted, returns null.
        /// </returns>
        public IWord ShiftActive(Keys key, IWord active)
        {
            // The deleted word id is set to null, could not shift anwhere. Returns null
            if (active.Id == null)
                return null;
            // Get the shifted word according to representation and the type of the word
            return (IWord)active.Accept(designer.ShiftActive,key);
        }

        /// <summary>
        /// Returns the context menu according to the representation and the type of the word.
        /// </summary>
        /// <param name="word">The word whose context menu should be returned</param>
        /// <param name="sentences">The set of sentences in whole file - to handle actions from the context menu</param>
        /// <param name="form">Commander with methods on the main form - to handle actions from the context menu</param>
        /// <returns></returns>
        public ContextMenuStrip GetContextMenu(IWord word, ListOfSentences sentences, ChangeActiveCommander form)
        {
            // Gets the context menu strip according to representation and the type of the word
            return (ContextMenuStrip)word.Accept(designer.GetContextMenu, sentences, form);
        }
    }
}