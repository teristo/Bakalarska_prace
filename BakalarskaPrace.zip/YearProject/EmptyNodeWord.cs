﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    /// <summary>
    /// Class representing a word that is omitted in the sentence by an ellipse
    /// </summary>
    public class EmptyNodeWord : Word, IWord
    { 
        /// <summary>
        /// The word before this group of empty words
        /// </summary>
        public IWord MainWord { get; set; }
        /// <summary>
        /// The floor, where the empty word is visualised in the sentence graph is the same floor as <seealso cref="MainWord"/>
        /// </summary>
        public override int Level
        {
            get
            {
                // If the main word is the part of multiword token
                if (MainWord.IsJoined)
                    return MainWord.JoinedWord.Level;
                return MainWord.Level;
            }
        }

        /// <summary>
        /// Creates the empty node word. 
        /// </summary>
        /// <param name="id">The id of the empty word. Must be decimal.</param>
        public EmptyNodeWord(string id) : base(null, id)
        {
        }

        /// <summary>
        /// Overrides the word <seealso cref="Word.AddChild(IWord, bool)"/> method. Empty node word can not accept any child.
        /// </summary>
        /// <param name="word">Word that tries to be the child of the empty word</param>
        /// <param name="removeFromActualParent">Specifies if the word should be removed from the original parent children</param>
        public override void AddChild(IWord word, bool removeFromParent) { }

        /// <summary>
        /// Shifts the first part of the id. Main word id is changed.
        /// </summary>
        /// <exception cref="ArgumentException">If the id is not in a forn x.y, where x and  are numbers.</exception>
        /// <exception cref="FormatException">Bad form of id.</exception>
        /// <param name="shift">The number by which the id is shifted.</param>
        public override void ShiftId(int shift)
        {
            string[] orig = Id.Split('.');
            if (orig.Length != 2)
                throw new ArgumentException();
            int new_id = int.Parse(orig[0]) + shift;
            Id = new_id + "." + orig[1];
        }

        /// <summary>
        /// Specifies if this word can be parent of the <paramref name="child"/> in the parameter. Allways return false, empty node can not have children.
        /// </summary>
        /// <param name="child">The word that tries to be the the child of the empty word node</param>
        /// <returns>Allways returns false.</returns>
        public override bool CanBeParentOf(IWord child)
        {
            return false;
        }

        /// <summary>
        /// Deletes the word and shift the ids of the following empty words
        /// </summary>
        /// <param name="sentence">The sentence where this word lies.</param>
        public override void Delete(ISentence sentence)
        {
            if(MainWord != null)
            {
                // The set of following empty nodes.
                var nextEmpty = MainWord.EmptyNodes.SkipWhile(x => x != this);
                foreach(var x in nextEmpty)
                {
                    // Decreases the second part of the id.
                    string[] splitted = x.Id.Split('.');
                    x.Id = splitted[0] + "." + (int.Parse(splitted[1]) - 1);
                }
                MainWord.EmptyNodes.Remove(this);
            }
            // Makes this id null to signalize it is deleted
            Id = null;
            // Deletes the word from the sentence
            sentence.DeleteWord(this, false);
        }

        /// <summary>
        /// Swaps the empty node with the next empty node in this group according to the direction
        /// </summary>
        /// <param name="direction">The direction that specifies the shift.</param>
        /// <returns>true if the words were swapped</returns>
        public bool Swap(int direction)
        {
            // The index of the empty word in the group of the empty words
            int idx = MainWord.EmptyNodes.IndexOf(this);
            // If there is no word which can be swapped with this word 
            if (MainWord.EmptyNodes.Count > idx + 1)
            {
                // Switches the nodes
                EmptyNodeWord sibling = MainWord.EmptyNodes[idx + 1];
                MainWord.EmptyNodes[idx] = sibling;
                MainWord.EmptyNodes[idx + 1] = this;
                string sibId = sibling.Id;
                sibling.Id = Id;
                Id = sibId;
                return true;
            }
            else return false;
        }

        /// <summary>
        /// Returns the form which is a part of the sentence. 
        /// Returns ällways the empty string because the empty word is omitted from the sentence.
        /// </summary>
        /// <returns>Returns allways the empty string.</returns>
        public override string GetFormToSentence()
        {
            return "";
        }

        /// <summary>
        /// Method to design the word according to the representation - Applies the received visitor on this word
        /// </summary>
        /// <param name="visitor">The class which allows this word to make some operation.</param>
        /// <param name="parameters">The parameters which are passed to the suitable method of the visitor</param>
        /// <returns>The return value of the visitor</returns>

        public override object Accept(IVisitor visitor, params object[] parameters)
        {
            return visitor.Visit(this, parameters);
        }
    }
}
