﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    public partial class FindSentenceBox : Form
    {
        public string SentId
        {
            get
            {
                return idBox.Text;
            }
        }
        public string SentRegex
        {
            get
            {
                return sentBox.Text;
            }
        }
        public FindSentenceBox(EventHandler nextSentence)
        {
            InitializeComponent();
            OKHandler = nextSentence;
        }
        private EventHandler OKHandler;
        private void OKButton_Click(object sender, EventArgs e)
        {
            OKHandler.Invoke(sender, e);
        }
        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                OKButton_Click(OKButton, null);
            }
        }
    }
}
