﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    class DrawWordBasic : DrawPointBasic, IVisitor
    {
        public DrawWordBasic(GraphicsSchema schema) : base(schema)
        {
        }
        public override object Visit(Word word, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            DrawLine(word, g);
            DrawPoint(word, g);
            return true;
        }

        public override object Visit(MultiWord multiWord, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            IWord first = multiWord.GetSubWord(multiWord.From);
            IWord last = multiWord.GetSubWord(multiWord.To);
            List<IWord> tops = new List<IWord>();
            List<IWord> downs = new List<IWord>();
            int start = int.Parse(multiWord.From);
            for (int i = start; i <= int.Parse(multiWord.To); i++)
            {
                IWord sub = multiWord.GetSubWord(i.ToString());
                if (sub.Level == multiWord.Level)
                    tops.Add(sub);
                if (sub.Level == multiWord.GetMaxLevel())
                    downs.Add(sub);
            }
            PointF[] points = FindPointsToJoin(first, last, tops, downs);
            JoinAllPoints(points, g);
            return true;
        }

        public override object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            return false;
        }
        protected virtual void DrawLine(Word word, Graphics g)
        {
            if (word.Parent != null)
            {
                DrawOneLine(word.GetPoint(), word.Parent.GetPoint(), g);
            }
        }
        protected void DrawOneLine(PointF child, PointF parent, Graphics g)
        {
            Pen pen = new Pen(schema.ColorOfGraph, 3);
            g.DrawLine(pen, child.X + schema.sizeOfPoint.Width / 2, child.Y + schema.sizeOfPoint.Height / 2,
                    parent.X + schema.sizeOfPoint.Width / 2, parent.Y + schema.sizeOfPoint.Height);
        }
        
        private PointF[] FindPointsToJoin(IWord left, IWord right, List<IWord> top, List<IWord> down)
        {
            List<PointF> result = new List<PointF>();
            result.Add(left.GetPoint());
            result.Add(new PointF(left.GetPoint().X, left.GetPoint().Y + schema.sizeOfPoint.Height));
            result.Add(new PointF(down[0].GetPoint().X, down[0].GetPoint().Y + schema.sizeOfPoint.Height));
            result.Add(new PointF(down[down.Count - 1].GetPoint().X + schema.sizeOfPoint.Width, down[down.Count - 1].GetPoint().Y + schema.sizeOfPoint.Height));
            result.Add(new PointF(right.GetPoint().X + schema.sizeOfPoint.Width, right.GetPoint().Y + schema.sizeOfPoint.Height));
            result.Add(new PointF(right.GetPoint().X + schema.sizeOfPoint.Width, right.GetPoint().Y));
            result.Add(new PointF(top[top.Count - 1].GetPoint().X + schema.sizeOfPoint.Width, top[top.Count - 1].GetPoint().Y));
            result.Add(top[0].GetPoint());
            PointF[] resultArr = result.Distinct().ToArray();
            return resultArr;            
        }
        private void JoinAllPoints(PointF[] points, Graphics graphics)
        {
            Pen p = new Pen(Color.DarkRed, 2);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            graphics.DrawClosedCurve(p, points, 0.3f, System.Drawing.Drawing2D.FillMode.Alternate);
        }
    }
    class DrawWordEnhanced : DrawPointEnhanced, IVisitor
    {
        public DrawWordEnhanced(GraphicsSchema schema) : base(schema)
        {
        }
        public override object Visit(Word word, params object[] parameters)
        {
            if (word.IsJoined)
                return false;
            Graphics g = (Graphics)parameters[0];
            DrawLine(word, g);
            DrawPoint(word, g);
            return true;
        }

        public override object Visit(MultiWord multiWord, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            DrawLine(multiWord, g);
            DrawPoint(multiWord, g);
            return true;
        }

        public override object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            base.DrawPoint(emptyWord, g);
            g.DrawEllipse(schema.OmittedWordCircumference, emptyWord.GetPoint().X, emptyWord.GetPoint().Y, schema.sizeOfPoint.Width, schema.sizeOfPoint.Height);
            return true;
        }

        protected void DrawLine(MultiWord word, Graphics g)
        {
            Pen pen = new Pen(schema.ColorOfGraph, 3);
            foreach (var w in word.Parents)
            {
                IWord joiningParent = w;
                if (w.IsJoined)
                {
                    joiningParent = w.JoinedWord;
                }
                DrawSpecialLine(word.GetPoint(), joiningParent.GetPoint(), g);
            }
        }

        private void DrawSpecialLine(PointF child, PointF parent, Graphics g)
        {
            if (child == parent)
                return;
            PointF pointChild;
            PointF pointParent;
            int up = 0;
            if (child.X < parent.X)
            {
                pointChild = new PointF(child.X + schema.sizeOfPoint.Width / 2, child.Y);
                pointParent = new PointF(parent.X + schema.sizeOfPoint.Width / 2, parent.Y);
                up = -1;
            }
            else
            {
                pointChild = new PointF(child.X + schema.sizeOfPoint.Width / 2, child.Y + schema.sizeOfPoint.Height);
                pointParent = new PointF(parent.X + schema.sizeOfPoint.Width / 2, parent.Y + schema.sizeOfPoint.Height);
                up = 1;
            }
            float trX = (pointParent.X - pointChild.X) / 3;
            float trY = (pointParent.Y - pointChild.Y) / 3;
            PointF[] points = new PointF[4];
            points[0] = pointChild;
            points[1] = new PointF(pointChild.X + trX, pointChild.Y + trY + up * schema.sizeOfPoint.Height * 2);
            points[2] = new PointF(pointChild.X + 2 * trX, pointChild.Y + 2 * trY + up * schema.sizeOfPoint.Height * 2);
            points[3] = pointParent;
            Pen pen = new Pen(schema.ColorOfGraph);
            pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            g.DrawCurve(pen, points);
        }
        protected void DrawLine(Word word, Graphics g)
        {
            if (word.Parent != null)
            {
                IWord joiningParent = word.Parent;
                if (word.Parent.JoinedWord != null)
                {
                    joiningParent = word.Parent.JoinedWord;
                }
                DrawOneLine(word.GetPoint(), joiningParent.GetPoint(), g);
            }
        }
        private void DrawPoint(MultiWord word, Graphics g)
        {
            base.DrawPoint(word, g);
            g.DrawEllipse(schema.JoinedWordCircumference, word.GetPoint().X, word.GetPoint().Y, schema.sizeOfPoint.Width, schema.sizeOfPoint.Height);
        }
        private void DrawPoint(EmptyNodeWord word, Graphics g)
        {
            base.DrawPoint(word, g);
            g.DrawEllipse(schema.OmittedWordCircumference, word.GetPoint().X, word.GetPoint().Y, schema.sizeOfPoint.Width, schema.sizeOfPoint.Height);
        }
        protected void DrawOneLine(PointF child, PointF parent, Graphics g)
        {
            Pen pen = new Pen(schema.ColorOfGraph, 3);
            g.DrawLine(pen, child.X + schema.sizeOfPoint.Width / 2, child.Y + schema.sizeOfPoint.Height / 2,
                    parent.X + schema.sizeOfPoint.Width / 2, parent.Y + schema.sizeOfPoint.Height);
        }
    }
}
