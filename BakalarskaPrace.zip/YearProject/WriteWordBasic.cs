﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    class WriteWordBasic : IVisitor
    {
        protected GraphicsSchema schema;
        public WriteWordBasic(GraphicsSchema schema)
        {
            this.schema = schema;
        }
        public virtual object Visit(Word word, params object[] parameters)
        {
            return WriteString(word.info.Form, parameters);
        }
        protected bool WriteString(string form, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            float x = Convert.ToSingle(parameters[1]);
            float y = Convert.ToSingle(parameters[2]);
            g.DrawString(form, schema.BoldFont, schema.StringBrush, x, y);
            return true;
        }
        public virtual object Visit(MultiWord multiWord, params object[] parameters) { return false; }

        public virtual object Visit(EmptyNodeWord emptyWord, params object[] parameters) { return false; }
    }
    class WriteWordEnhanced : WriteWordBasic, IVisitor
    {
        public WriteWordEnhanced(GraphicsSchema schema) : base(schema)
        {
        }
        public override object Visit(Word word, params object[] parameters)
        {
            if (!word.IsJoined)
            {
                return base.Visit(word, parameters);
            }
            return false;
        }

        public override object Visit(MultiWord multiWord, params object[] parameters)
        {
            return WriteString(multiWord.info.Form, parameters);
        }

        public override object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            return WriteString(emptyWord.info.Form, parameters);
        }
    }
}
