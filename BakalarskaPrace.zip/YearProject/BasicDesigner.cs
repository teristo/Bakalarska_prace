﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    class BasicDesigner : IDesigner
    {
        public IVisitor DrawWord { get; protected set; }

        public IVisitor DrawPoint { get; protected set; }

        public IVisitor WriteWord { get; protected set; }

        public IVisitor FormSize { get; protected set; }

        public IVisitor ShiftActive { get; protected set; }

        public IVisitor GetContextMenu { get; protected set; }

        public virtual void CreateVisitors(GraphicsSchema schema)
        {
            DrawWord = new DrawWordBasic(schema);
            DrawPoint = new DrawPointBasic(schema);
            WriteWord = new WriteWordBasic(schema);
            FormSize = new FormSizeBasic(schema);
            ShiftActive = new ShiftActiveBasic(schema);
            GetContextMenu = new GetMenuBasic(schema);
        }
    }
    class EnhancedDesigner : BasicDesigner, IDesigner
    {
        public override void CreateVisitors(GraphicsSchema schema)
        {
            DrawWord = new DrawWordEnhanced(schema);
            DrawPoint = new DrawPointEnhanced(schema);
            WriteWord = new WriteWordEnhanced(schema);
            FormSize = new FormSizeEnhanced(schema);
            ShiftActive = new ShiftActiveEnhanced(schema);
            GetContextMenu = new GetMenuEnhanced(schema);
        }
    }
}
