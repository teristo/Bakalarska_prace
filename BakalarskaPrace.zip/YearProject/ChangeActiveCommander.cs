﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    public class ChangeActiveCommander
    {
        private Form1 mainForm;
        public ChangeActiveCommander(Form1 form)
        {
            mainForm = form;
        }
        public void ChangeActiveWord(IWord w)
        {
            mainForm.ChangeActiveWord(w);
        }
        public void ChangeActiveSentence(ISentence s)
        {
            mainForm.ChangeActiveSentence(s);
        }
        public void VisualiseNewGraph()
        {
            mainForm.visualiseNewGraph();
        }
    }
}
