﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    public interface ISentence
    {
        Word Root { get; }
        int placeInFile { get; set; }
        int CountWords { get; }
        string Sent_id { get; }
        string Text_attribute { get; }
        void AddWord(IWord word, int position);
        IWord InsertChild(IWord parent, IWord preceding);
        void DeleteWord(IWord word, bool shiftIds);
        IWord GetWord(int index);
        IWord GetWord(string id);
        int GetIndexOf(IWord word);
        void Swap(IWord first, IWord second);
        Sentence Split(IWord firstWord, string new_id, ListOfSentences sentences);
        void ShowInfo();
        string MakeText();
        void SaveTo(FileStream stream);
    }
}
