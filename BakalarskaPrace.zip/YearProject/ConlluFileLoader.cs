﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    class ConlluFileLoader : SimpleFileLoader, IFileLoader
    {
        public ConlluFileLoader(Panel tp) : base(tp)
        {
        }
        public override bool LoadFile(ListOfSentences sentences)
        {
            string Filename;
            if (PrepareOpenFileDialog(out Filename) == DialogResult.OK)
            {
                InformAboutLoading();
                try
                {
                    using (Reader reader = new Reader(Filename))
                    {
                        sentences.AddSentences(new ConlluSentencesFactory(reader));
                        return true;
                    }
                }
                catch 
                {
                    MessageBox.Show("File is not in a CoNLL-U format.");
                    return false;
                }
            }
            Graphics g = TreePanel.CreateGraphics();
            g.Clear(Color.White);
            return true;
        }
    }
}
