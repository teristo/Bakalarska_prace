﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    class ConlluSentencesFactory : ISentencesFactory
    {
        class OneSentenceParts
        {
            Dictionary<WordInfo, int> positions = new Dictionary<WordInfo, int>();
            Dictionary<int, List<WordInfo>> words = new Dictionary<int, List<WordInfo>>();
            Dictionary<int, List<EmptyNodeWord>> emptyNodes = new Dictionary<int, List<EmptyNodeWord>>();
            Dictionary<int, MultiWord> joined = new Dictionary<int, MultiWord>();
            List<string> sentenceInfo = new List<string>();
            public bool IsEmpty { get => positions.Count == 0 && sentenceInfo.Count == 0; }
            public void AddWord(string[] properties)
            {
                WordInfo info = new WordInfo(properties);
                bool idIsInt = int.TryParse(info.Id, out int Id);
                if (idIsInt)
                {
                    AddBasicWord(info);
                }
                else
                {
                    if (!TryAddMultiword(info) && !TryAddEmptyWord(info))
                    {
                        throw new FormatException();
                    }
                }
                positions.Add(info, positions.Count + 1);
            }
            private void AddBasicWord(WordInfo info)
            {
                int intParent = int.Parse(info.Head);
                if (!words.ContainsKey(intParent))
                {
                    words[intParent] = new List<WordInfo>();
                }
                words[intParent].Add(info);
            }
            private bool TryAddMultiword(WordInfo info)
            {
                string[] splittedJoined = info.Id.Split('-');
                if (splittedJoined.Length == 2)
                {
                    MultiWord new_joined = new MultiWord(info.Form, info.Id)
                    {
                        info = info
                    };
                    for (int i = int.Parse(splittedJoined[0]); i <= int.Parse(splittedJoined[1]); i++)
                    {
                        joined.Add(i, new_joined);
                    }
                    return true;
                }
                return false;
            }
            private bool TryAddEmptyWord(WordInfo info)
            {
                string[] splittedEmpty = info.Id.Split('.');
                if (splittedEmpty.Length == 2)
                {
                    int mainWordId = int.Parse(splittedEmpty[0]);
                    if (!emptyNodes.ContainsKey(mainWordId))
                    {
                        emptyNodes.Add(mainWordId, new List<EmptyNodeWord>());
                    }
                    EmptyNodeWord empty = new EmptyNodeWord(info.Id)
                    {
                        info = info
                    };
                    emptyNodes[mainWordId].Add(empty);
                    return true;
                }
                return false;
            }
            public void AddInfo(string line)
            {
                char[] trimmedChars = { '#', ' ' };
                sentenceInfo.Add(line.Trim(trimmedChars));
            }
            private void AddChildren(int parentID, Word rootWord, IWord[] allWords)
            {
                if (words.ContainsKey(parentID))
                {
                    foreach (var info in words[parentID])
                    {
                        Word word = new Word(rootWord, info.Id)
                        {
                            info = info
                        };
                        int int_id = int.Parse(info.Id);
                        if (joined.ContainsKey(int_id))
                        {
                            joined[int_id].AddSubWord(word, null);
                            if (joined[int_id].From == info.Id)
                                allWords[positions[joined[int_id].info]] = joined[int_id];
                        }
                        allWords[positions[info]] = word;
                        if (emptyNodes.ContainsKey(int_id))
                        {
                            word.EmptyNodes = emptyNodes[int_id];
                            foreach (EmptyNodeWord empty in emptyNodes[int_id])
                            {
                                empty.MainWord = word;
                                allWords[positions[empty.info]] = empty;
                            }
                        }
                        AddChildren(int_id, word, allWords);
                    }
                }
            }
            private bool CheckJoined(Sentence sentence)
            {
                foreach(var word in joined)
                {
                    if ((sentence.GetWord(word.Key.ToString())) == null)
                    {
                        return false;
                    }
                }
                return true;
            }
            private bool CheckEmpty(Sentence sentence)
            {
                foreach (var word in emptyNodes)
                {
                    if ((sentence.GetWord(word.Key.ToString())) == null)
                    {
                        return false;
                    }
                }
                return true;
            }
            public Sentence Get(ListOfSentences sentences)
            {
                if (IsEmpty)
                    return null;
                Word Root = new Word(null, "0");
                IWord[] allWords = new IWord[positions.Count + 1];
                allWords[0] = Root;
                string sent_id = "";
                AddChildren(0, Root, allWords);
                for (int i = 0; i < sentenceInfo.Count; ++i)
                {
                    var line = sentenceInfo[i].Split('=');
                    if (line[0].Trim() == "sent_id")
                    {
                        sent_id = line[1];
                    }
                }
                Sentence sentence = new Sentence(Root, allWords.ToList(), sent_id,  sentenceInfo, sentences);
                if (!CheckJoined(sentence) || !CheckEmpty(sentence))
                    throw new FormatException();
                return sentence;
            }
        }
        private readonly Reader reader;
        public ConlluSentencesFactory(Reader reader)
        {
            this.reader = reader;
        }


        private void Load(Reader reader, OneSentenceParts ActualSent)
        {
            string line;
            while ((line = reader.ReadLineAsString()) != null)
            {
                if (line == "")
                {
                    return;
                }
                else if (line[0] == '#')
                {
                    ActualSent.AddInfo(line);
                }
                else
                {
                    string[] props = line.Split('\t');
                    ActualSent.AddWord(props);
                }
            }
        }

        public Sentence GetSentence(ListOfSentences sentences)
        {
            OneSentenceParts ActualSent = new OneSentenceParts();
            Load(reader, ActualSent);
            return ActualSent.Get(sentences);
        }        
    }
}
