﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    class DrawPointBasic : IVisitor
    {
        protected GraphicsSchema schema;
        public DrawPointBasic(GraphicsSchema schema)
        {
            this.schema = schema;
        }
        public virtual object Visit(Word word, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            DrawPoint(word, g);
            return true;
        }

        public virtual object Visit(MultiWord multiWord, params object[] parameters) { return false; }

        public virtual object Visit(EmptyNodeWord emptyWord, params object[] parameters) { return false; }
   
        public virtual void DrawPoint(Word word, Graphics g)
        {
            if (word.IsActive)
            {
                g.FillEllipse(schema.ColorOfActiveNode, word.GetPoint().X, word.GetPoint().Y, schema.sizeOfPoint.Width, schema.sizeOfPoint.Height);
            }
            else
                g.FillEllipse(schema.ColorOfGraph, word.GetPoint().X, word.GetPoint().Y, schema.sizeOfPoint.Width, schema.sizeOfPoint.Height);
        }
    }
    class DrawPointEnhanced : DrawPointBasic, IVisitor
    {
        public DrawPointEnhanced(GraphicsSchema schema) : base(schema)
        {
        }
        public override object Visit(Word word, params object[] parameters)
        {
            if (!word.IsJoined)
            {
                return base.Visit(word, parameters);
            }
            return false;
        }
        public override object Visit(MultiWord multiWord, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            DrawPoint(multiWord, g);
            return true;
        }

        public override object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            DrawPoint(emptyWord, g);
            return true;
        }
        private void DrawPoint(MultiWord word, Graphics g)
        {
            base.DrawPoint(word, g);
            g.DrawEllipse(schema.JoinedWordCircumference, word.GetPoint().X, word.GetPoint().Y, schema.sizeOfPoint.Width, schema.sizeOfPoint.Height);
        }
        private void DrawPoint(EmptyNodeWord word, Graphics g)
        {
            base.DrawPoint(word, g);
            g.DrawEllipse(schema.OmittedWordCircumference, word.GetPoint().X, word.GetPoint().Y, schema.sizeOfPoint.Width, schema.sizeOfPoint.Height);
        }
    }
}
