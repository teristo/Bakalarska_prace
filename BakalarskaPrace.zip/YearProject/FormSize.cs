﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    class FormSizeBasic : IVisitor
    {
        protected GraphicsSchema schema;
        public FormSizeBasic(GraphicsSchema schema)
        {
            this.schema = schema;
        }
        public virtual object Visit(Word word, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            return GetFormSize(word.info.Form, g, schema.BoldFont);
           
        }
        public SizeF GetFormSize(string form, Graphics g, Font f)
        {
            SizeF size = g.MeasureString(form, f);
            if (size.Width < schema.sizeOfPoint.Width)
                size = new SizeF(schema.sizeOfPoint.Width, size.Height);
            return size;
        }
        public virtual object Visit(MultiWord multiWord, params object[] parameters)
        {
            return new SizeF(0,0);
        }

        public virtual object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            return new SizeF(0,0);
        }

    }
    class FormSizeEnhanced : FormSizeBasic, IVisitor
    {
        public FormSizeEnhanced(GraphicsSchema schema) : base(schema)
        {
        }
        public override object Visit(Word word, params object[] parameters)
        {
            if (!word.IsJoined)
            { 
                return base.Visit(word, parameters);
            }
            return new SizeF(0, 0);
        }
        public override object Visit(MultiWord multiWord, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            return GetFormSize(multiWord.info.Form, g, schema.BoldFont);
        }

        public override object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            Graphics g = (Graphics)parameters[0];
            return GetFormSize(emptyWord.info.Form, g, schema.BoldFont);
        }

    }
}
