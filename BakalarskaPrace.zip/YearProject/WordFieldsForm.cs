﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    public partial class WordFieldsForm : Form
    {
        private WordInfo Info { get; set; }
        private ISentence Sentence { get; set; }
        public bool ValuesMustBeChecked { get; set; }

        private List<string> usedFeats = new List<string>();
        private List<string> usedMisc = new List<string>();
        private List<string> usedDeps = new List<string>();
        public WordFieldsForm(WordInfo info, ISentence sentence)
        {
            InitializeComponent();
            Info = info;
            Sentence = sentence;
            ValuesMustBeChecked = true;
            AddRows();
        }

        public WordFieldsForm(WordInfo info)
        {
            InitializeComponent();
            this.Info = info;
            ValuesMustBeChecked = false;
            AddRows();
        }

        public void InitButton(string text, params EventHandler[] handlers)
        {
            button.Text = text;
            foreach (EventHandler handler in handlers)
            {
                button.Click += handler;
            }
        }
        public void InitTitle(string text)
        {
            Font newFont = new Font("Microsoft Sans Serif", 8.5f, FontStyle.Bold);
            Label title = new Label
            {
                TextAlign = ContentAlignment.MiddleCenter,
                Text = text,
                Dock = DockStyle.Top
            };
        }
        protected void AddRows()
        {
            table.Rows.Clear();
            foreach(KeyValuePair<string, string> property in Info.Properties())
            {
                string[] row = { property.Key, property.Value };
                table.Rows.Add(row);
                if (property.Key == nameof(WordInfo.Feats) && property.Value != "")
                {
                    usedFeats.Add(property.Value.Split('=')[0]);
                }

                if (property.Key == nameof(WordInfo.Misc) && property.Value != "")
                {
                    usedMisc.Add(property.Value.Split('=')[0]);
                }

                if (property.Key == nameof(WordInfo.Deps) && property.Value != "")
                {
                    usedDeps.Add(property.Value.Split(':')[0]);
                }
            }
            if (ValuesMustBeChecked)
            {
                MakeSpecialReadOnly();
            }
            table.Visible = true;
        }
        private void MakeSpecialReadOnly()
        {
            table[1, 0].ReadOnly = true;
            if (Info.Id.Split('-').Count() > 1)
            {
                foreach (DataGridViewRow row in table.Rows)
                {
                    if ((string)row.Cells[0].Value != nameof(WordInfo.Form) && (string)row.Cells[0].Value != nameof(WordInfo.Misc))
                        row.Cells[1].ReadOnly = true;
                }
            }
            if (Info.Id.Split('.').Count() > 1)
            {
                foreach (DataGridViewRow row in table.Rows)
                {
                    if ((string)row.Cells[0].Value == nameof(WordInfo.Head) || (string)row.Cells[0].Value == nameof(WordInfo.Deprel))
                        row.Cells[1].ReadOnly = true;
                }
            }
        }
        private void ChangedValue(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || e.ColumnIndex > 1) return;
            if ((string)table[0, e.RowIndex].Value == nameof(WordInfo.Feats) || 
                (string)table[0, e.RowIndex].Value == nameof(WordInfo.Misc) ||
                (string)table[0, e.RowIndex].Value == nameof(WordInfo.Deps))
            {
                if ((string)table[e.ColumnIndex, e.RowIndex].Value == "" || table[e.ColumnIndex, e.RowIndex].Value == null)
                {
                    if (e.RowIndex + 1 < table.RowCount && (string)table[0, e.RowIndex + 1].Value == (string)table[0, e.RowIndex].Value)
                    {
                        table.Rows.RemoveAt(e.RowIndex);
                    }
                }
                else if ((e.RowIndex + 1 < table.RowCount && (string)table[0, e.RowIndex + 1].Value != (string)table[0, e.RowIndex].Value)
                    || e.RowIndex + 1 == table.RowCount)
                {
                    string[] row = { (string)table[0, e.RowIndex].Value, "" };
                    table.Rows.Insert(e.RowIndex + 1, row);
                }
            }
        }
        private void ValidateCell(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (!ValuesMustBeChecked || e.ColumnIndex >= 2) return;
            if (table[e.ColumnIndex, e.RowIndex].ReadOnly == true)
                return;
            else if (((string)table[0, e.RowIndex].Value) == nameof(WordInfo.Id) || ((string)table[0, e.RowIndex].Value) == nameof(WordInfo.Head))
            {
                if (!int.TryParse(e.FormattedValue.ToString(), out int res))
                {
                    CancelValidation(e, message: "The value must be an integer.");
                    return;
                }
            }
            else if ((string)table[0, e.RowIndex].Value == nameof(WordInfo.Feats) )
            {
                ValidateDictValue(e, usedFeats, '=');
            }
            else if((string)table[0, e.RowIndex].Value == nameof(WordInfo.Misc))
            {
                ValidateDictValue(e, usedMisc, '=');
            }
            if (Sentence == null)        //it is only for defining key shortcuts -> sentence is null
                return;
            if (((string)table[0, e.RowIndex].Value) == nameof(WordInfo.Head))
            {
                string value = e.FormattedValue.ToString();
                IWord parent = Sentence.GetWord(value);
                IWord word = Sentence.GetWord(Info.Id);
                if (Sentence.GetWord(value) == null || Info.Id == value || !parent.CanBeParentOf(word))
                {
                    CancelValidation(e, message: "The value must be a valid ID of another word. The new head can not be a descendant of this word.");
                }
            }
            if (((string)table[0, e.RowIndex].Value) == nameof(WordInfo.Deps) && (string)e.FormattedValue != "")
            {
                string[] splitted = ((string)e.FormattedValue).Split(':');
                IWord parent = Sentence.GetWord(splitted[0]);
                IWord word = Sentence.GetWord(Info.Id);
                if (splitted.Length < 2 || Sentence.GetWord(splitted[0]) == null)
                {
                    CancelValidation(e, message: "The first part must be a valid ID of another word.");
                }
            }
        }
        private bool ValidateDictValue(DataGridViewCellValidatingEventArgs e, List<string> used, char delim)
        {
            if ((string)e.FormattedValue == "")
            {
                string[] splittedO = ((string)table[1, e.RowIndex].Value).Split(delim);
                if (splittedO.Length == 2)
                       used.Remove(splittedO[0]);
                return true;
            }
            string[] splitted = ((string)e.FormattedValue).Split(delim);
            if (splitted.Length != 2)
            {
                CancelValidation(e, message: "The value must be in the format 'x" + delim + "value'.");
                return false;
            }
            string[] splittedOrig = ((string)table[1, e.RowIndex].Value).Split(delim);
            if (used.Contains(splitted[0]) && splittedOrig[0] != splitted[0])
            {
                CancelValidation(e, message: "This value is already set.");
                return false;
            }
            else used.Add(splitted[0]);
            return true;
        }
        private void CancelValidation(DataGridViewCellValidatingEventArgs e, string message)
        {
            e.Cancel = true;
            table.CancelEdit();
            MessageBox.Show(message);
        }
        public List<KeyValuePair<string, string>> GetState()
        {
            List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
            foreach(var row in table.Rows.Cast<DataGridViewRow>())
            {
                list.Add( new KeyValuePair<string, string> ( (string)row.Cells[0].Value, (string)row.Cells[1].Value ));
            }
            return list;
        }
    }
}
