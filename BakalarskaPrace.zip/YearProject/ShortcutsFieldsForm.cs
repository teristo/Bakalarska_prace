﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    public class ShortcutsFieldsForm : WordFieldsForm
    {
        public Keys GetShortcutKeys()
        {
            return ShortcutKeys;
        }

        public void SetShortcutKeys(Keys sc)
        {
            ShortcutKeys = sc;
        }

        private List<ItemInWordInfo> Result { get; set; }
        private Keys ShortcutKeys { get; set; }

        public List<ItemInWordInfo> GetResult()
        {
            return Result;
        }

        public ShortcutsFieldsForm(WordInfo info) : base(info, null)
        {
            AddRows();
            table.Rows.RemoveAt(8);
            table.Rows.RemoveAt(6);
            table.Rows.RemoveAt(0);
            shortcutPanel.Visible = true;
            var new_col = new DataGridViewCheckBoxColumn
            {
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            };
            table.Columns.Add(new_col);

            foreach (DataGridViewRow row in table.Rows)
            {
                row.Cells[2].ToolTipText = "Owerwrite original not empty value?";
            }
            InitButton(text: "Set shortcut keys", handlers: SaveState);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (ActiveControl != shortcutTextBox)
                return base.ProcessCmdKey(ref msg, keyData);
            if (keyData.HasFlag(Keys.Control) || keyData.HasFlag(Keys.Shift) || keyData.HasFlag(Keys.Alt))
            {
                shortcutTextBox.Text = keyData.ToString();
                ShortcutKeys = keyData;
            }
            else
            {
                MessageBox.Show(text: "Please, use CONTROL, SHIFT or ALT key");
            }
            return true;
        }

        private void SaveState(object sender, EventArgs e)
        {
            if (shortcutTextBox.Text == "")
            {
                MessageBox.Show(text: "You must define the shortcut key.");
                return;
            }
            Result = new List<ItemInWordInfo>();
            foreach (DataGridViewRow row in table.Rows)
            {
                string name = (string)row.Cells[0].Value;
                string value = (string)row.Cells[1].Value;
                bool overwrite = (row.Cells[2].Value != null && (bool)row.Cells[2].Value);
                if (value == "" && overwrite == false)
                    continue;
                ItemInWordInfo item = new ItemInWordInfo(name, value, overwrite);
                Result.Add(item);
            }
            DialogResult = DialogResult.OK;
            Close();
        }
    }
    public class ItemInWordInfo
    {
        public string Name { get; }
        public string Value { get; }
        public bool Overwrite { get; }
        public ItemInWordInfo(string n, string v, bool o)
        {
            Name = n;
            Value = v;
            Overwrite = o;
        }
    }
}
