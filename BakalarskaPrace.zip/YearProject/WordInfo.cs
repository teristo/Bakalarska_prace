﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.IO;

namespace YearProject
{
    public class WordInfo
    {
        /// <summary>
        /// The Id of the word. Numeric for the basic word, decimal for the empty node word and the range for the multiword token.
        /// </summary>
        public string Id { get; set; } = "";
        /// <summary>
        /// Word form or punctuation symbol.
        /// </summary>
        public string Form { get; set; } = "";
        /// <summary>
        /// Lemma or stem of word form.
        /// </summary>
        public string Lemma { get; private set; } = "";
        /// <summary>
        /// Universal part-of-speech tag.
        /// </summary>
        public string Upos { get; private set; } = "";
        /// <summary>
        /// Language-specific part-of-speech tag.
        /// </summary>
        public string Xpos { get; private set; } = "";
        /// <summary>
        /// List of morphological features
        /// </summary>
        public Dictionary<string, string> Feats { get; private set; } = new Dictionary<string, string>();
        /// <summary>
        /// Head of the current word, which is either a value of ID or zero (0).
        /// </summary>
        public string Head { get; set; } = "";
        /// <summary>
        /// Universal dependency relation to the HEAD (root iff HEAD = 0) or a defined language-specific subtype of one.
        /// </summary>
        public string Deprel { get; private set; } = "";
        /// <summary>
        /// Enhanced dependency graph in the form of a list of head-deprel pairs.
        /// </summary>
        public Dictionary<string, string> Deps { get; private set; } = new Dictionary<string, string>();
        /// <summary>
        /// Any other annotation.
        /// </summary>
        public Dictionary<string, string> Misc { get; private set; } = new Dictionary<string, string>();
        private ISentence Sentence { get; set; }
        private const char delimFeatsMisc = '=';
        private const char delimDeps = ':';
        public WordInfo()
        {
        }
        public WordInfo(string[] properties)
        {
            Id = properties[0];
            Form = properties[1];
            Lemma = properties[2];
            Upos = ImportValue(properties[3]);
            Xpos = ImportValue(properties[4]);
            SaveDictValues(properties[5], Feats, delimFeatsMisc);
            Head = ImportValue(properties[6]);
            Deprel = ImportValue(properties[7]);
            SaveDictValues(properties[8], Deps, delimDeps);
            SaveDictValues(properties[9], Misc, delimFeatsMisc);
        }
        private void SaveDictValues(string valueInFile, Dictionary<string, string> dict, char delim)
        {
            dict.Clear();
            if (valueInFile != "_" && valueInFile != "")
            {
                string[] arr = valueInFile.Split('|');
                foreach (var value in arr)
                {
                    string[] oneProp = value.Split(delim);
                    //if (oneProp.Length != 2) throw new FormatException();
                    //else
                        dict.Add(oneProp[0], oneProp[1]);
                }
            }
        }
        private void SaveDictValues(Dictionary<string, string> dict, IGrouping<string, KeyValuePair<string, string>> values, char delim)
        {
            dict.Clear();
            foreach (var value in values)
            {
                if (value.Value == "")
                    continue;
                string[] spltted = value.Value.Split(delim);
                dict.Add(spltted[0], spltted[1]);
            }
        }
        public void SaveChanges(WordFieldsForm form)
        {
            var state = form.GetState();
            var changed = from row in state.GroupBy(x => x.Key)
                          join field in GetType().GetProperties() on row.Key equals field.Name
                          select new { field, row };
            foreach (var change in changed)
            {          
                if(change.row.Key == nameof(Feats))
                {
                    SaveDictValues(Feats, change.row, delimFeatsMisc);
                }
                else if (change.row.Key == nameof(Misc))
                {
                    SaveDictValues(Misc, change.row, delimFeatsMisc);
                }
                else if (change.row.Key == nameof(Deps))
                {
                    SaveDictValues(Deps, change.row, delimDeps);
                }
                else
                {
                    if (change.field.Name == nameof(Head) && Sentence != null)
                    {
                        IWord word = Sentence.GetWord(int.Parse(Id));
                        IWord parent = Sentence.GetWord(int.Parse(change.row.FirstOrDefault().Value));
                        parent.AddChild(word, true);
                    }
                    change.field.SetValue(this, change.row.FirstOrDefault().Value);
                }
            }
        }
        public void ShowWordInfo(ISentence s)
        {
            Sentence = s;
            WordFieldsForm f = new WordFieldsForm(this, s);
            f.InitButton("Save changes", (e, sender) => { SaveChanges(f); f.Close(); });
            f.ShowDialog();
        }
        public void ApplyChanges(Dictionary<string, ItemInWordInfo> actions,
                                    Dictionary<string, ItemInWordInfo> feats,
                                    Dictionary<string, ItemInWordInfo> misc)
        {
            var fields = GetType().GetProperties();
            foreach (var field in fields)
            {
                string name = field.Name;
                if (name == nameof(Feats))
                {
                    Feats = SaveDictionaryRecords(feats, Feats);
                }
                else if (name == nameof(Misc))
                {
                    Misc = SaveDictionaryRecords( misc, Misc);
                }
                else if (actions.ContainsKey(name))
                {
                    ItemInWordInfo ac = actions[name];
                    if (ac.Overwrite || (string)field.GetValue(this) == "")
                    {
                        field.SetValue(this, ac.Value);
                    }
                }
            }
        }
        private Dictionary<string, string> SaveDictionaryRecords(Dictionary<string, ItemInWordInfo> changes, Dictionary<string, string> orig)
            {
            bool removeother = false;
            if (changes.ContainsKey("") && changes[""].Overwrite == true)
                removeother = true;
            Dictionary<string, string> Changed = new Dictionary<string, string>();
            foreach (var pair in changes)
            {
                if (pair.Value.Overwrite || !orig.ContainsKey(pair.Key))
                {
                    Changed.Add(pair.Value.Name, pair.Value.Value);
                }
                else if (orig.ContainsKey(pair.Key))
                {
                    Changed.Add(pair.Key, orig[pair.Key]);
                }
            }
            if (!removeother)
            {
                foreach (var pair in orig)
                {
                    if (!Changed.ContainsKey(pair.Key))
                    {
                        Changed.Add(pair.Key, pair.Value);
                    }
                }
            }
            return Changed;
        }
        private string ExportValue(string val)
        {
            return val == "" ? "_" : val;
        }
        private string ImportValue(string val)
        {
            return val == "_" ? "" : val;
        }

        public IEnumerable<KeyValuePair<string, string>> Properties()
        {
            yield return new KeyValuePair<string, string>(nameof(Id), Id);        
            yield return new KeyValuePair<string, string>(nameof(Form), Form);
            yield return new KeyValuePair<string, string>(nameof(Lemma), Lemma);
            yield return new KeyValuePair<string, string>(nameof(Upos), Upos);
            yield return new KeyValuePair<string, string>(nameof(Xpos), Xpos);
            foreach (var val in Feats)
            {
                yield return new KeyValuePair<string, string>(nameof(Feats), val.Key + delimFeatsMisc + val.Value);
            }
            yield return new KeyValuePair<string, string>(nameof(Feats), "");
            yield return new KeyValuePair<string, string>(nameof(Head), Head);
            yield return new KeyValuePair<string, string>(nameof(Deprel), Deprel);
            foreach (var val in Deps)
            {
                yield return new KeyValuePair<string, string>(nameof(Deps), val.Key + delimDeps + val.Value);
            }
            yield return new KeyValuePair<string, string>(nameof(Deps), "");
            foreach (var val in Misc)
            {
                yield return new KeyValuePair<string, string>(nameof(Misc), val.Key + delimFeatsMisc + val.Value);
            }
            yield return new KeyValuePair<string, string>(nameof(Misc), "");
        }

        public void SaveWord(FileStream file)
        {
            StringBuilder sb = new StringBuilder();
            string last = null;
            foreach (var prop in Properties())
            {
                if (last == prop.Key)
                {
                    if (prop.Value == "")
                        continue;
                    sb.Append('|');
                }
                else if (last != null) 
                    sb.Append('\t');                
                sb.Append(ExportValue(prop.Value));
                last = prop.Key;
            }           
            sb.Append(Environment.NewLine);
            byte[] bytes = Encoding.Default.GetBytes(sb.ToString());
            file.Write(bytes, 0, bytes.Length);
        }
    }
}
