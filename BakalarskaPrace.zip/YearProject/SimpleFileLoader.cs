﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    public interface IFileLoader
    {
        bool LoadFile(ListOfSentences sentences);
    }
    class SimpleFileLoader : IFileLoader
    {
        protected Panel TreePanel;
        public SimpleFileLoader(Panel tp)
        {
            TreePanel = tp;
        }
        
        protected void InformAboutLoading()
        {
            Graphics g = TreePanel.CreateGraphics();
            g.Clear(Color.White);
            string text = "Please, wait a moment...";
            Font font = new Font("Arial", 15);
            SizeF sizeText = g.MeasureString(text, font);
            PointF p = new PointF((TreePanel.Width / 2) - (sizeText.Width / 2), (TreePanel.Height / 2) - (sizeText.Height / 2));
            g.DrawString(text, font, Brushes.Black, p);
        }
        public virtual bool LoadFile(ListOfSentences sentences)
        {
            string Filename;
            if (PrepareOpenFileDialog(out Filename) == DialogResult.OK)
            {
                InformAboutLoading();
                try
                {
                    using (Reader reader = new Reader(Filename))
                    {                        
                        sentences.AddSentences(new SimpleSentencesFactory(reader));
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
            Graphics g = TreePanel.CreateGraphics();
            g.Clear(Color.White);
            return true;
        }
        public static DialogResult PrepareOpenFileDialog(out string Filename)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            openFile.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFile.FilterIndex = 2;
            openFile.RestoreDirectory = true;
            var result = openFile.ShowDialog();
            if (result == DialogResult.OK)
                Filename = openFile.FileName;
            else
                Filename = null;
            return result;
        }
        public static DialogResult PrepareSaveFileDialog(out string Filename)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.DefaultExt = "txt";
            saveDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            var result = saveDialog.ShowDialog();
            if (result == DialogResult.OK)
                Filename = saveDialog.FileName;
            else
                Filename = null;
            return result;
        }
    }
}
