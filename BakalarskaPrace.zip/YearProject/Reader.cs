﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace YearProject
{
    public class Reader : IDisposable
    {
        TextReader file;
        string[] line;
        int indexInLine = 0;
        Encoding FileEncoding;
        const byte maxArrayLength = 128;
        char[] array = new char[maxArrayLength];
        public Reader(string filename)
        {
            FileEncoding = GetFileEncoding(filename);
            file = new StreamReader(new FileStream(filename, FileMode.Open), FileEncoding);
        }
        public Reader(TextBox textbox)
        {
            FileEncoding = Encoding.Unicode;
            file = new StringReader(textbox.Text);
        }
        public string ReadWord()
        {
            indexInLine++;
            if (indexInLine == line.Length)
            {
                line = ReadLine();
                indexInLine = 0;
            }
            if (line == null) return null;
            return line[indexInLine];
        }
        public string[] ReadLine()
        {
            string line = ReadLineAsString();
            if (line != null)
                return line.Split();
            else return null;
        }
        public string ReadLineAsString()
        {
            string line = file.ReadLine();
            if (line == null)
            {
                EndOfFile = true;
                return null;
            }
            return line;
        }
        public bool EndOfFile { get; set; } = false;
        public void Dispose()
        {
            if(file!= null)
            {
                file.Close();
            }
        }
        public static Encoding GetFileEncoding(string path)
        {
            var encodings = Encoding.GetEncodings()
                .Select(e => e.GetEncoding())
                .Select(e => new { Encoding = e, Preamble = e.GetPreamble() })
                .Where(e => e.Preamble.Any())
                .ToArray();

            var maxPrembleLength = encodings.Max(e => e.Preamble.Length);
            byte[] buffer = new byte[maxPrembleLength];

            using (var stream = File.OpenRead(path))
            {
                stream.Read(buffer, 0, (int)Math.Min(maxPrembleLength, stream.Length));
            }

            return encodings
                .Where(enc => enc.Preamble.SequenceEqual(buffer.Take(enc.Preamble.Length)))
                .Select(enc => enc.Encoding)
                .FirstOrDefault() ?? FindEncoding(path);
        }
        private static Encoding FindEncoding(string filename)
        {
            FileStream fs = new FileStream(filename, FileMode.Open);
            try
            {
                int test_length = 1000;
                byte[] b = new byte[test_length];
                fs.Read(b, 0, test_length);
                test_length = b.Length;

                int i = 0;
                bool utf8 = false;
                while (i < test_length - 4)
                {
                    if (b[i] <= 0x7F)
                    { i += 1; continue; }     
                    if (b[i] >= 0xC2 && b[i] <= 0xDF && b[i + 1] >= 0x80 && b[i + 1] < 0xC0)
                    { i += 2; utf8 = true; continue; }
                    if (b[i] >= 0xE0 && b[i] <= 0xF0 && b[i + 1] >= 0x80 && b[i + 1] < 0xC0 && b[i + 2] >= 0x80 && b[i + 2] < 0xC0)
                    { i += 3; utf8 = true; continue; }
                    if (b[i] >= 0xF0 && b[i] <= 0xF4 && b[i + 1] >= 0x80 && b[i + 1] < 0xC0 && b[i + 2] >= 0x80 && b[i + 2] < 0xC0 && b[i + 3] >= 0x80 && b[i + 3] < 0xC0)
                    { i += 4; utf8 = true; continue; }
                    utf8 = false; break;
                }
                if (utf8 == true)
                {
                    return Encoding.UTF8;
                }
                return Encoding.Default;
            }
            finally
            {
                fs.Close();
            }
        }
    }
}
