﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    public class ListOfSentences
    {
        private Dictionary<string, ISentence> sentences = new Dictionary<string, ISentence>();
        private Panel filePanel;
        private Panel pagePanel;
        private ChangeActiveCommander mainForm;
        private int shownPage = -1;
        private bool ChangedSentences = false;
        private List<Control> ids_on_panel = new List<Control>();
        private int countOfPages;
        private const int onOnePage = 70;
        private string ActiveId;
        public ISentence ActiveSentence { get; private set;}
        public ListOfSentences(Panel filePanel, Panel pagePanel, ChangeActiveCommander f)
        {
            this.filePanel = filePanel;
            filePanel.Controls.Clear();
            this.pagePanel = pagePanel;
            pagePanel.Controls.Clear();
            mainForm = f;
        }
        public void AddNew(ISentence sentence, int index)
        {
            sentence.placeInFile = index;
            sentences.Add(sentence.Sent_id, sentence);
            var label = MakeSentenceLinkButton(sentence.Sent_id);
            ids_on_panel.Add(label);
        }
        public void InsertNew(ISentence sentence, int index)
        {
            sentence.placeInFile = index;
            if (index < ids_on_panel.Count)
            {
                for (int i = index; i < ids_on_panel.Count; i++)
                {
                    sentences[ids_on_panel[i].Text].placeInFile++;
                }
            }
            ChangedSentences = true;
            sentences.Add(sentence.Sent_id, sentence);
            LinkLabel label = MakeSentenceLinkButton(sentence.Sent_id);
            ids_on_panel.Insert(index, label);
            filePanel.Controls.Add(label);
            filePanel.Controls.SetChildIndex(label, index % onOnePage);
            if (ids_on_panel.Count % onOnePage == 1)
            {
                var page = MakePageButton(ids_on_panel.Count / onOnePage + 1);
                pagePanel.Controls.SetChildIndex(page, 0);
            }
        }
        private LinkLabel MakePageButton(int num)
        {
            LinkLabel label = new LinkLabel();
            label.Text = num.ToString();
            label.AutoSize = true;
            label.Padding = new Padding(1);
            label.LinkClicked += Page_LinkClicked;
            label.TabStop = true;            
            label.Dock = DockStyle.Left;
            pagePanel.Controls.Add(label);
            return label;
        }
        private LinkLabel MakeSentenceLinkButton(string text)
        {
            LinkLabel label = new LinkLabel();
            label.Text = text;
            label.LinkClicked += Label_LinkClicked;
            label.Dock = DockStyle.Top;
            label.Padding = new Padding(1);
            label.AutoSize = true;
            return label;
        }
        public void ShowAll()
        {
            filePanel.Controls.Clear();
            pagePanel.Controls.Clear();
            countOfPages =( ids_on_panel.Count - 1) / onOnePage + 1;
            for (int i = countOfPages; i > 0; i--)
            {
                MakePageButton(i);
            }            
        }
        private void Page_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int actPage = int.Parse(((LinkLabel)sender).Text);
            if (shownPage == actPage && !ChangedSentences) return;
            ChangedSentences = false;
            if (shownPage != -1)
            {
                ((LinkLabel)pagePanel.Controls[pagePanel.Controls.Count - shownPage]).LinkColor = System.Drawing.Color.DarkSlateBlue;
            }
            ((LinkLabel)sender).LinkColor = System.Drawing.Color.Salmon;
            int end = (actPage - 1) * onOnePage;
            int start = actPage * onOnePage;
            if (start > ids_on_panel.Count) start = ids_on_panel.Count;
            filePanel.Controls.Clear();
            int maxSize = 0;
            for (int i = start-1;i >= end; i--)
            {
                filePanel.Controls.Add(ids_on_panel[i]);
                if (ids_on_panel[i].Width > maxSize)
                    maxSize = ids_on_panel[i].Width;
            }
            filePanel.AutoScrollMinSize = new System.Drawing.Size(maxSize, filePanel.AutoScrollMinSize.Height);
            shownPage = actPage;
        }
        private void Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                string sent_id = ((LinkLabel)sender).Text;
                mainForm.ChangeActiveSentence(sentences[sent_id]);
            }
            else
            {
                ContextMenuStrip menu = new ContextMenuStrip();
                ToolStripMenuItem delete = new ToolStripMenuItem("Delete sentence");
                delete.Click += (s, eh) => { RemoveSentence((LinkLabel)sender); };
                menu.Items.Add(delete);
                ToolStripMenuItem join = new ToolStripMenuItem("Join sentence with the next");
                join.Click += (s, eh) => { JoinSentences((LinkLabel)sender); };
                menu.Items.Add(join);
                ToolStripMenuItem insert = new ToolStripMenuItem("Insert new sentence after this");
                insert.Click += (s, eh) => { InsertEmptySentence((LinkLabel)sender); };
                menu.Items.Add(insert);
                menu.Show((Control)sender, 0, 0);
            }
        }

        private void InsertEmptySentence(Control sourceControl)
        {
            ISentence preceding = sentences[sourceControl.Text];
            ISentence new_sent = MakeNewSentence();
            if (new_sent == null) return;
            InsertNew(new_sent, preceding.placeInFile + 1);
            mainForm.ChangeActiveSentence(new_sent);
        }

        private void RemoveSentence(Control linkOfSentence)
        {
            ids_on_panel.Remove(linkOfSentence);
            filePanel.Controls.Remove(linkOfSentence);
            int place = sentences[linkOfSentence.Text].placeInFile;
            for (int i = place; i < ids_on_panel.Count; i++)
            {
                sentences[ids_on_panel[i].Text].placeInFile--;
            }
            if (sentences[linkOfSentence.Text] == ActiveSentence)
            {
                int new_active = Math.Max(place - 1, 0);
                if (ids_on_panel.Count > new_active)
                    mainForm.ChangeActiveSentence(sentences[ids_on_panel[new_active].Text]);
                else mainForm.ChangeActiveSentence(null);
            }
            if (ids_on_panel.Count % onOnePage == 0)
            {
                pagePanel.Controls.RemoveAt(0);
            }
            sentences.Remove(linkOfSentence.Text);

        }
        private void JoinSentences(Control sourceControl)
        {
            ISentence actual = sentences[sourceControl.Text];
            int index = ids_on_panel.IndexOf(sourceControl);
            if (ids_on_panel.Count > index + 1)
            {
                ISentence next = sentences[ids_on_panel[index + 1].Text];
                int shiftId = actual.CountWords - 1;
                for (int i = 1; i < next.CountWords; i++)
                {
                    IWord w = next.GetWord(i);
                    if (w.Parent != null && w.Parent.Parent == null)
                    {
                        actual.Root.AddChild(w, true);
                        w.ShiftId(shiftId);
                    }
                    else
                        w.ShiftId(shiftId);
                    actual.AddWord(w, actual.CountWords);
                }
                RemoveSentence(ids_on_panel[index + 1]);
                mainForm.ChangeActiveSentence(actual);
            }
        }
        public void Split(ISentence sentence, IWord word)
        {
            string new_id = sentence.Sent_id + "_2";
            int copyNum = 2;
            while (GetSentence(new_id) != null)
            {
                copyNum++;
                new_id = sentence.Sent_id + "_" + copyNum;
            }
            ISentence new_sent = sentence.Split(word, new_id, this);
            if (new_sent == null)
                return;
            InsertNew(new_sent, sentence.placeInFile + 1);
            mainForm.ChangeActiveSentence(new_sent);
        }
        public ISentence GetSentence(int index)
        {
            if (ids_on_panel.Count > index && index >= 0)
            {
                return sentences[ids_on_panel[index].Text];
            }
            else return null;
        }
        public ISentence GetSentence(string id)
        {
            if (sentences.ContainsKey(id))
            {
                return sentences[id];
            }
            else return null;
        }
        public void changeActive(ISentence sentence)
        {
            if (ActiveId != null){
                if (ids_on_panel.Count > ActiveSentence.placeInFile)
                {
                    var old_link = ids_on_panel[ActiveSentence.placeInFile];
                    ((LinkLabel)old_link).LinkColor = System.Drawing.Color.DarkSlateBlue;    //visited sentence
                }
            }
            if(sentence != null)
            {                
                var link = ids_on_panel[sentence.placeInFile];
                ((LinkLabel)link).LinkColor = System.Drawing.Color.Salmon;       //active sentence
                ActiveId = sentence.Sent_id;
                int page = sentence.placeInFile / onOnePage;
                Page_LinkClicked(pagePanel.Controls[pagePanel.Controls.Count - page - 1], null);
            }
            ActiveSentence = sentence;

        }
        public void SaveAll(string nameOfSaved)
        {
            FileStream newFile = File.Create(nameOfSaved);
            foreach (var control in ids_on_panel)
            {
                ISentence sentence = sentences[control.Text];
                sentence.SaveTo(newFile);
                byte[] bytes = Encoding.Default.GetBytes(Environment.NewLine);
                newFile.Write(bytes, 0, bytes.Length);
            }
            newFile.Close();
        }

        public void SetId(ISentence sentence, string new_id)
        {
            sentences.Remove(sentence.Sent_id);
            sentences.Add(new_id, sentence);
            ids_on_panel[sentence.placeInFile] = MakeSentenceLinkButton(new_id);
            filePanel.Controls[filePanel.Controls.Count - sentence.placeInFile].Text = new_id;
        }

        public ISentence MakeNewSentence()
        {
            InsertNewSentenceBox inputBox = new InsertNewSentenceBox(sentences);
            if (inputBox.ShowDialog() == DialogResult.OK)
            {
                string sent_id = inputBox.IdBox;
                Reader r = new Reader(inputBox.Sentence);
                ISentence sentence = new Sentence(r.ReadLine(), sent_id, this);
                return sentence;
            }
            return null;
        }

        public void AddSentences(ISentencesFactory factory)
        {
            int index = 0;
            Sentence sentence;
            while((sentence = factory.GetSentence(this)) != null)
            {
                AddNew(sentence, index);
                index++;
            }            
            ShowAll();
        }
    }
}
