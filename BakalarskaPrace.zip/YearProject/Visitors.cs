﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    public interface IVisitor
    {
        object Visit(Word word, params object[] parameters);
        object Visit(MultiWord multiWord, params object[] parameters);
        object Visit(EmptyNodeWord emptyWord, params object[] parameters);
    }
    public interface IDesigner
    {
        IVisitor DrawWord { get; }
        IVisitor DrawPoint { get; }
        IVisitor WriteWord { get; }
        IVisitor FormSize { get; }
        IVisitor ShiftActive { get; }
        IVisitor GetContextMenu { get; }
        void CreateVisitors(GraphicsSchema schema);
    }
}
