﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    public interface IWord
    {
        IWord Parent { get; set; }
        WordInfo info { get; set; }
        SortedList<int, IWord> Children { get; }
        string Id { get; set; }

        PointF GetPoint();
        void SetPoint(PointF value);
        bool MatchPoint(PointF searchedPoint, Size sizeOfPoint);
        void ShiftId(int shift);
        void ShowInfo(ISentence sentence);
        string[] GetWordBasicInfo(string sent_id);
        void AddChild(IWord w, bool removeFromActualParent);
        void RemoveChild(string id);
        int Level { get; set; }
        MultiWord JoinedWord { get; set; }
        List<EmptyNodeWord> EmptyNodes { get; }
        bool IsJoined { get; }
        bool IsActive { get; set; }
        bool CanBeParentOf(IWord par);
        void SaveToFile(FileStream stream);
        IWord GetSiblingOfChild(IWord child, int direction);
        string GetFormToSentence();
        bool CanStartNewSentence(out string reason);
        void Delete(ISentence sentence);
        object Accept(IVisitor visitor, params object[] parameters);
    }
}
