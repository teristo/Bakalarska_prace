﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    /*
     * The class implements the interface IFinder to search in a file. 
     * It search in sentences according to sentence id or regular expression, which the user inputs.
     * It automatically search for the next sentence when the user clicks the next button.
     * User can change the parameters and in the end of the file, he or she can search from the beginning.
     */
    class SentenceFinder : IFinder
    {
        ISentence sentence;
        ChangeActiveCommander form;
        ListOfSentences sentences;
        private string lastFoundSentence;
        public SentenceFinder(ChangeActiveCommander f, ListOfSentences sents)
        {
            form = f;
            sentences = sents;
        }
        public void Find(ISentence first)
        {
            sentence = sentences.GetSentence(first.placeInFile - 1);    //previous
            lastFoundSentence = first.Sent_id;
            FindSentenceBox dialog = new FindSentenceBox(FindNextSentence);
            dialog.ShowDialog();
            if (dialog.DialogResult == DialogResult.OK)
            {
                return;
            }
        }
        private ISentence FindFirstSentenceFromIndex(string pattern)
        {
            int actId;
            if (sentence != null) actId = sentence.placeInFile + 1;
            else actId = 0;
            sentence = sentences.GetSentence(actId);
            Regex r = new Regex(pattern);
            while (sentence != null && !r.IsMatch(sentence.Text_attribute))
            {
                actId++;
                sentence = sentences.GetSentence(actId);
                if (sentence == null)
                    return null;
            }
            return sentence;
        }
        private ISentence GetFirstSentenceAccordingToParams(FindSentenceBox findForm, out bool validRegex)
        {
            ISentence result = null;
            if (findForm.SentId != "")
            {
                result = sentences.GetSentence(findForm.SentId);
            }
            else
            {
                string pattern = findForm.SentRegex;
                if (!string.IsNullOrEmpty(pattern))
                {
                    try
                    {
                        result = FindFirstSentenceFromIndex(pattern);
                    }
                    catch (ArgumentException)
                    {
                        MessageBox.Show("The expression must be a valid regular expression.");
                        validRegex = false;
                        return null;
                    }
                }
            }
            validRegex = true;
            return result;
        }
        private void FindNextSentence(object sender, EventArgs e)
        {
            FindSentenceBox findForm = (FindSentenceBox)((Button)sender).FindForm();
            ISentence result = GetFirstSentenceAccordingToParams(findForm, out bool validRegex);
            if (result != null)
            {
                form.ChangeActiveSentence(sentence);
                lastFoundSentence = result.Sent_id;
            }
            else if (validRegex)
            {
                DialogResult change;
                if (lastFoundSentence != null)
                    change = MessageBox.Show("No other sentence matches the parameters. Do you want to search from beginning?", "Change your parameters", MessageBoxButtons.YesNo);
                else
                    change = MessageBox.Show("No sentence matches the parameters. Do you want to search from beginning?", "Change your parameters", MessageBoxButtons.YesNo);
                if (change == DialogResult.No)
                {
                    sentence = sentences.GetSentence(lastFoundSentence);
                    form.ChangeActiveWord(null);
                }
                else
                {
                    sentence = sentences.GetSentence(0);
                    FindNextSentence(sender, e);
                }
            }
        }
    }
}
