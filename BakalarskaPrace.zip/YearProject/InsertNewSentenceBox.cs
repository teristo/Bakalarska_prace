﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    public partial class InsertNewSentenceBox : Form
    {
        private Dictionary<string, ISentence> sentences;
        public string IdBox
        {
            get
            {
                return idBox.Text;
            }
        }
        public TextBox Sentence
        {
            get
            {
                return sentBox;
            }
        }
        public InsertNewSentenceBox(Dictionary<string, ISentence> sentences)
        {
            InitializeComponent();
            this.sentences = sentences;
        }
        private void Submit(object sender, EventArgs e)
        {
            if(IdBox == "")
            {
                MessageBox.Show("The id can not be empty.");
                return;
            }
            if (sentences.ContainsKey(IdBox))
            {
                MessageBox.Show("This id is occupied! You must use another one.");
                return;
            }
            DialogResult = DialogResult.OK;
        }        

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                Submit(OKButton, null);
            }
        }
    }
}

