﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YearProject
{
    public interface ISentencesFactory
    {
        Sentence GetSentence(ListOfSentences sentences);
    }
    class SimpleSentencesFactory : ISentencesFactory
    {
        private Reader reader;
        private int idNum = 0;
        public SimpleSentencesFactory(Reader reader)
        {
            this.reader = reader;
        }
        public Sentence GetSentence(ListOfSentences sentences)
        {
            if(!reader.EndOfFile)
            {
                Sentence sentence = new Sentence(reader.ReadLine(), "s" + idNum.ToString(), sentences);
                idNum++;
                return sentence;
            }
            return null;
        }
    }
}
