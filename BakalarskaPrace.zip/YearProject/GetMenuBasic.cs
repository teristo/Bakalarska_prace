﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    class GetMenuBasic : IVisitor
    {
        protected GraphicsSchema schema;
        protected ToolStripMenuItem WordInfoItem;
        protected ToolStripMenuItem SentenceInfoItem;
        protected ToolStripMenuItem AddChildItem;
        protected ToolStripMenuItem SplitNodeItem;
        protected ToolStripMenuItem DeleteItem;

        public GetMenuBasic(GraphicsSchema schema)
        {
            this.schema = schema;
        }
        public virtual object Visit(Word word, params object[] parameters)
        {
            ListOfSentences sentences = (ListOfSentences)parameters[0];
            ChangeActiveCommander form = (ChangeActiveCommander)parameters[1];
            if (word.Parent == null)
            {
                return RootMenu(word, sentences, form);
            }
            ContextMenuStrip menu = new ContextMenuStrip();

            prepareItems(word, sentences, form);            

            menu.Items.Add(WordInfoItem);
            menu.Items.Add(AddChildItem);
            menu.Items.Add(SplitNodeItem);
            menu.Items.Add(DeleteItem);

            if (!word.IsJoined)
            {
                ToolStripMenuItem ShiftLeftItem = new ToolStripMenuItem("Shift word to left");
                ShiftLeftItem.Click += (sender, e) => {
                    word.Swap(-1, sentences.ActiveSentence);
                    form.VisualiseNewGraph();
                };
                menu.Items.Add(ShiftLeftItem);

                ToolStripMenuItem ShiftRightItem = new ToolStripMenuItem("Shift word to right");
                ShiftRightItem.Click += (sender, e) => {
                    word.Swap(1, sentences.ActiveSentence);
                    form.VisualiseNewGraph();
                };
                menu.Items.Add(ShiftRightItem);

                ToolStripMenuItem SplitSentenceItem = new ToolStripMenuItem("Split sentence here");
                SplitSentenceItem.Click += (sender, e) => {
                    sentences.Split(sentences.ActiveSentence, word);
                    form.VisualiseNewGraph();
                };
                menu.Items.Add(SplitSentenceItem);
            }
            else if(word.IsJoined && word.JoinedWord.From == word.Id)
            {
                ToolStripMenuItem SplitSentenceItem = new ToolStripMenuItem("Split sentence here");
                SplitSentenceItem.Click += (sender, e) => {
                    sentences.Split(sentences.ActiveSentence, word.JoinedWord);
                    form.VisualiseNewGraph();
                };
                menu.Items.Add(SplitSentenceItem);
            }

            return menu;
        }
        protected ContextMenuStrip RootMenu(Word word, ListOfSentences sentences, ChangeActiveCommander form)
        {
            prepareItems(word, sentences, form);
            ContextMenuStrip menu = new ContextMenuStrip();

            menu.Items.Add(SentenceInfoItem);
            menu.Items.Add(AddChildItem);
            return menu;
        }
        protected void prepareItems(Word word, ListOfSentences sentences, ChangeActiveCommander form)
        {
            WordInfoItem = new ToolStripMenuItem("Show info about word");
            WordInfoItem.Click += (sender, e) => {
                word.ShowInfo(sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };

            SentenceInfoItem = new ToolStripMenuItem("Show info about sentence");
            SentenceInfoItem.Click += (sender, e) => { sentences.ActiveSentence.ShowInfo(); };

            AddChildItem = new ToolStripMenuItem("Add child");
            AddChildItem.Click += (sender, e) => {
                sentences.ActiveSentence.InsertChild(word, word);
                form.VisualiseNewGraph();
            };

            SplitNodeItem = new ToolStripMenuItem("Split node");
            SplitNodeItem.Click += (sender, e) => {
                if (word.Parent == null) return;
                sentences.ActiveSentence.InsertChild(word.Parent, word);
                form.VisualiseNewGraph();
            };

            
            DeleteItem = new ToolStripMenuItem("Delete node");
            DeleteItem.Click += (sender, e) => {
                word.Delete(sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };

        }
        public virtual object Visit(MultiWord multiWord, params object[] parameters) { return null; }

        public virtual object Visit(EmptyNodeWord emptyWord, params object[] parameters) { return null; }

    }

    class GetMenuEnhanced : GetMenuBasic, IVisitor
    {
        public GetMenuEnhanced(GraphicsSchema schema) : base(schema) { }
        public override object Visit(Word word, params object[] parameters)
        {
            ListOfSentences sentences = (ListOfSentences)parameters[0];
            ChangeActiveCommander form = (ChangeActiveCommander)parameters[1];
            if (word.Parent == null)
            {
                return RootMenu(word, sentences, form);
            }
            ContextMenuStrip menu = new ContextMenuStrip();
            prepareItems(word, sentences, form);

            ToolStripMenuItem AddEmptyItem = new ToolStripMenuItem("Insert empty node after");
            AddEmptyItem.Click += (sender, e) => {
                word.AddEmptyNode(sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };

            ToolStripMenuItem MakeMultiWordItem = new ToolStripMenuItem("Make multiword with the next node");
            MakeMultiWordItem.Click += (sender, e) => {
                IWord next = GetNextNotEmpty(word, sentences.ActiveSentence);
                if (next == null) return;
                MultiWord MW = new MultiWord(word, next, sentences.ActiveSentence);
                sentences.ActiveSentence.AddWord(MW, sentences.ActiveSentence.GetIndexOf(word));
                form.VisualiseNewGraph();
            };

            ToolStripMenuItem ShiftLeftItem = new ToolStripMenuItem("Shift word to left");
            ShiftLeftItem.Click += (sender, e) => {
                word.Swap(-1, sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };

            ToolStripMenuItem ShiftRightItem = new ToolStripMenuItem("Shift word to right");
            ShiftRightItem.Click += (sender, e) => {
                word.Swap(1, sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };

            menu.Items.Add(WordInfoItem);
            menu.Items.Add(AddChildItem);
            menu.Items.Add(AddEmptyItem);
            menu.Items.Add(MakeMultiWordItem);
            menu.Items.Add(ShiftLeftItem);
            menu.Items.Add(ShiftRightItem);
            menu.Items.Add(DeleteItem);

            return menu;
        }

        public override object Visit(MultiWord multiWord, params object[] parameters)
        {
            ListOfSentences sentences = (ListOfSentences)parameters[0];
            ChangeActiveCommander form = (ChangeActiveCommander)parameters[1];
            ContextMenuStrip menu = new ContextMenuStrip();

            WordInfoItem = new ToolStripMenuItem("Show info about word");
            WordInfoItem.Click += (sender, e) => {
                multiWord.ShowInfo(sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };
            menu.Items.Add(WordInfoItem);

            ToolStripMenuItem AddNextToMultiItem = new ToolStripMenuItem("Add next node to this multiword token");
            AddNextToMultiItem.Click += (sender, e) => {
                IWord next = GetNextNotEmpty(multiWord.GetSubWord(multiWord.To), sentences.ActiveSentence);
                if (next == null) return;
                multiWord.AddSubWord(next, sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };
            menu.Items.Add(AddNextToMultiItem);

            ToolStripMenuItem RemoveMultiItem = new ToolStripMenuItem("Remove this multiword token");
            RemoveMultiItem.Click += (sender, e) => {
                multiWord.Delete(sentences.ActiveSentence);
                form.ChangeActiveWord(null);
                form.VisualiseNewGraph();
            };
            menu.Items.Add(RemoveMultiItem);

            return menu;
        }

        public override object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            ListOfSentences sentences = (ListOfSentences)parameters[0];
            ChangeActiveCommander form = (ChangeActiveCommander)parameters[1];
            ContextMenuStrip menu = new ContextMenuStrip();

            WordInfoItem = new ToolStripMenuItem("Show info about word");
            WordInfoItem.Click += (sender, e) => {
                emptyWord.ShowInfo(sentences.ActiveSentence);
                form.VisualiseNewGraph();
            };
            menu.Items.Add(WordInfoItem);

            DeleteItem = new ToolStripMenuItem("Delete node");
            DeleteItem.Click += (sender, e) => {
                emptyWord.Delete(sentences.ActiveSentence);
                form.ChangeActiveWord(null);
                form.VisualiseNewGraph();
            };
            menu.Items.Add(DeleteItem);

            ToolStripMenuItem SwapEmptyItem = new ToolStripMenuItem("Swap node with the next empty node");
            SwapEmptyItem.Click += (sender, e) => {
                emptyWord.Swap(+1);
                form.VisualiseNewGraph();
            };
            menu.Items.Add(SwapEmptyItem);

            return menu;
        }
        private IWord GetNextNotEmpty(IWord word, ISentence sentence)
        {
            int posFirst = sentence.GetIndexOf(word);
            IWord next = sentence.GetWord(posFirst + 1);
            int i = 2;
            while (next != null && next is EmptyNodeWord)
            {
                next = sentence.GetWord(posFirst + i);
            }
            return next;
        }
    }
}
