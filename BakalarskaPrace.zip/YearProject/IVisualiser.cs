﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    public interface IVisualiser
    {
        Size sizeOfPoint { get; }
        PointF scrollPosition { get; }
        void Visualise(ISentence sentence);
        void NewGraphics(ISentence sentence);
        void ScrollNewGraphics(ISentence sentence);
        void DrawOneWord(IWord w);
        bool ShowBasicInfo(Panel basicWordInfo, IWord word, ISentence sentence);
        IWord FindRightPoint(ISentence sentence, PointF origPoint);
        IWord ShiftActive(Keys key, IWord active);
        ContextMenuStrip GetContextMenu(IWord word, ListOfSentences sentences, ChangeActiveCommander form);
    }
}
