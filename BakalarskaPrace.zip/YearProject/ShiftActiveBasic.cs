﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YearProject
{
    class ShiftActiveBasic : IVisitor
    {
        protected GraphicsSchema schema;
        public ShiftActiveBasic(GraphicsSchema schema)
        {
            this.schema = schema;
        }
        public virtual object Visit(Word word, params object[] parameters)
        {
            Keys key = (Keys)parameters[0];
            return ShiftActive(key, word);
        }

        public virtual object Visit(MultiWord multiWord, params object[] parameters) { return null; }

        public virtual object Visit(EmptyNodeWord emptyWord, params object[] parameters) { return null; }
        public virtual IWord ShiftActive(Keys key, IWord word)
        {
            switch (key)
            {
                case Keys.Up:
                    if (word.Parent != null)
                        return word.Parent;
                    return word;
                case Keys.Down:
                    if (word.Children.Count > 0)
                        return word.Children.Values.ElementAt(0);
                    return word;
                case Keys.Left:
                    if (word.Parent == null)
                        return word;
                    return word.Parent.GetSiblingOfChild(word, -1);
                case Keys.Right:
                    if (word.Parent == null)
                        return word;
                    return word.Parent.GetSiblingOfChild(word, 1);
            }
            return word;
        }
    }
    class ShiftActiveEnhanced : ShiftActiveBasic, IVisitor
    {
        public ShiftActiveEnhanced(GraphicsSchema schema) : base(schema)
        {
        }
        public override object Visit(Word word, params object[] parameters)
        {
            Keys key = (Keys)parameters[0];
            var returned = base.ShiftActive(key, word);
            if (returned != word && returned.JoinedWord == word.JoinedWord && word.IsJoined)
            {
                return ShiftActive(Keys.Right, returned);
            }
            if (returned.IsJoined)
            {
                return returned.JoinedWord;
            }
            return returned;
        }

        public override object Visit(MultiWord multiWord, params object[] parameters)
        {
            Keys key = (Keys)parameters[0];
            switch (key)
            {
                case Keys.Left:
                    return ShiftActive(key, multiWord.GetSubWord(multiWord.From));
                case Keys.Right:
                    return ShiftActive(key, multiWord.GetSubWord(multiWord.To));
                default:
                    for (int i = int.Parse(multiWord.From); i <= int.Parse(multiWord.To); i++)
                    {
                        var returned = ShiftActive(key, multiWord.GetSubWord(i.ToString()));
                        if (multiWord != returned)
                            return returned;
                    }
                    return multiWord;
            }
        }

        public override object Visit(EmptyNodeWord emptyWord, params object[] parameters)
        {
            Keys key = (Keys)parameters[0];
            int index = int.Parse(emptyWord.Id.Split('.')[1]);
            switch (key)
            {
                case Keys.Left:
                    if (index > 1)
                        return emptyWord.MainWord.EmptyNodes[index - 2];
                    return emptyWord.MainWord;
                case Keys.Right:
                    if (emptyWord.MainWord.EmptyNodes.Count > index)
                        return emptyWord.MainWord.EmptyNodes[index];
                    return emptyWord;
                default:
                    return emptyWord;
            }
        }
    }
    
}
