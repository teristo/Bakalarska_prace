var class_conllu_visualiser_1_1_shortcut_validator =
[
    [ "ShortcutValidator", "class_conllu_visualiser_1_1_shortcut_validator.html#ab7faec2685b8f9cb5cfb6e2410425cd7", null ],
    [ "MakeReadonly", "class_conllu_visualiser_1_1_shortcut_validator.html#ab38c17a9a91fcfea1e08acae3a73c31b", null ],
    [ "ValidateCell", "class_conllu_visualiser_1_1_shortcut_validator.html#adeab846df0f51f9c7caab736389ce14a", null ]
];