var class_graph_visualiser_1_1_form_size_enhanced =
[
    [ "FormSizeEnhanced", "class_graph_visualiser_1_1_form_size_enhanced.html#ab4aa53f6df2b34184226b4564c0fef57", null ],
    [ "Visit", "class_graph_visualiser_1_1_form_size_enhanced.html#a73abdbb059c69fb64173b64114200d52", null ],
    [ "Visit", "class_graph_visualiser_1_1_form_size_enhanced.html#a1993e05d760b6badb493b26c0c32e26a", null ]
];