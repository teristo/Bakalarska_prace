var class_finder_1_1_find_sentence_box =
[
    [ "FindSentenceBox", "class_finder_1_1_find_sentence_box.html#a24aaa3db422075af212bc7d52506820d", null ],
    [ "Dispose", "class_finder_1_1_find_sentence_box.html#a8a98ac4dea9bb83569aa04655454f8cc", null ],
    [ "InitializeComponent", "class_finder_1_1_find_sentence_box.html#a2ce0d04b9a78c320b5e188e5f51c7909", null ],
    [ "OKButton_Click", "class_finder_1_1_find_sentence_box.html#a326c066488d56aefb99c54fa93682db3", null ],
    [ "components", "class_finder_1_1_find_sentence_box.html#a7aec3312f87d6404502c26cd31efb244", null ],
    [ "flowPanel", "class_finder_1_1_find_sentence_box.html#a0c26e19ba9df7430ab516fc5b88c96d4", null ],
    [ "idBox", "class_finder_1_1_find_sentence_box.html#a75fcbe28eb0f606b9091b20ba85d5efb", null ],
    [ "legendId", "class_finder_1_1_find_sentence_box.html#a186bc0092eada7b23ed7ad6a99441368", null ],
    [ "LegendSent", "class_finder_1_1_find_sentence_box.html#a1375101f210938bc29002edeb8327393", null ],
    [ "OKButton", "class_finder_1_1_find_sentence_box.html#a009f37f7fa67bf75ef85f9f9b2fd5eaa", null ],
    [ "OKHandler", "class_finder_1_1_find_sentence_box.html#a9f496589c4e0dda996ac055a5bc0bafc", null ],
    [ "sentBox", "class_finder_1_1_find_sentence_box.html#acd92a65105ed7faff7d1a398f110f16f", null ],
    [ "SentId", "class_finder_1_1_find_sentence_box.html#a0360ff910e3eb4be57d6a2fbcc892ea1", null ],
    [ "SentRegex", "class_finder_1_1_find_sentence_box.html#a31f7de8fee8d89b4e7659092ffb1140f", null ]
];