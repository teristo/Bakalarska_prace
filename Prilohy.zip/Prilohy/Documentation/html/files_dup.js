var files_dup =
[
    [ "AppForm.cs", "_app_form_8cs.html", [
      [ "AppForm", "class_conllu_visualiser_1_1_app_form.html", "class_conllu_visualiser_1_1_app_form" ]
    ] ],
    [ "AppForm.Designer.cs", "_app_form_8_designer_8cs.html", [
      [ "AppForm", "class_conllu_visualiser_1_1_app_form.html", "class_conllu_visualiser_1_1_app_form" ]
    ] ],
    [ "AttributeValidator.cs", "_attribute_validator_8cs.html", [
      [ "ConlluValidator", "class_conllu_visualiser_1_1_conllu_validator.html", "class_conllu_visualiser_1_1_conllu_validator" ]
    ] ],
    [ "BasicDesigner.cs", "_basic_designer_8cs.html", [
      [ "BasicDesigner", "class_graph_visualiser_1_1_basic_visualiser_1_1_basic_designer.html", "class_graph_visualiser_1_1_basic_visualiser_1_1_basic_designer" ]
    ] ],
    [ "BasicPointCounter.cs", "_basic_point_counter_8cs.html", [
      [ "BasicPointCounter", "class_graph_visualiser_1_1_basic_visualiser_1_1_basic_point_counter.html", "class_graph_visualiser_1_1_basic_visualiser_1_1_basic_point_counter" ]
    ] ],
    [ "BasicWord.cs", "_basic_word_8cs.html", [
      [ "BasicWord", "class_conllu_visualiser_1_1_basic_word.html", "class_conllu_visualiser_1_1_basic_word" ]
    ] ],
    [ "ConlluFileLoader.cs", "_conllu_file_loader_8cs.html", [
      [ "ConlluFileLoader", "class_conllu_visualiser_1_1_conllu_file_loader.html", "class_conllu_visualiser_1_1_conllu_file_loader" ]
    ] ],
    [ "ConlluSentenceFactory.cs", "_conllu_sentence_factory_8cs.html", [
      [ "ConlluSentenceFactory", "class_conllu_visualiser_1_1_conllu_sentence_factory.html", "class_conllu_visualiser_1_1_conllu_sentence_factory" ],
      [ "OneSentenceParts", "class_conllu_visualiser_1_1_conllu_sentence_factory_1_1_one_sentence_parts.html", "class_conllu_visualiser_1_1_conllu_sentence_factory_1_1_one_sentence_parts" ]
    ] ],
    [ "CurrentState.cs", "_current_state_8cs.html", [
      [ "CurrentState", "class_conllu_visualiser_1_1_current_state.html", "class_conllu_visualiser_1_1_current_state" ]
    ] ],
    [ "DrawPointBasic.cs", "_draw_point_basic_8cs.html", [
      [ "DrawPointBasic", "class_graph_visualiser_1_1_basic_visualiser_1_1_draw_point_basic.html", "class_graph_visualiser_1_1_basic_visualiser_1_1_draw_point_basic" ]
    ] ],
    [ "DrawPointEnhanced.cs", "_draw_point_enhanced_8cs.html", [
      [ "DrawPointEnhanced", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_draw_point_enhanced.html", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_draw_point_enhanced" ]
    ] ],
    [ "DrawWordBasic.cs", "_draw_word_basic_8cs.html", [
      [ "DrawWordBasic", "class_graph_visualiser_1_1_basic_visualiser_1_1_draw_word_basic.html", "class_graph_visualiser_1_1_basic_visualiser_1_1_draw_word_basic" ]
    ] ],
    [ "EmptyNodeWord.cs", "_empty_node_word_8cs.html", [
      [ "EmptyNodeWord", "class_conllu_visualiser_1_1_empty_node_word.html", "class_conllu_visualiser_1_1_empty_node_word" ]
    ] ],
    [ "EncodingDecoder.cs", "_encoding_decoder_8cs.html", [
      [ "EncodingDecoder", "class_conllu_visualiser_1_1_encoding_decoder.html", "class_conllu_visualiser_1_1_encoding_decoder" ]
    ] ],
    [ "EnhancedDesigner.cs", "_enhanced_designer_8cs.html", [
      [ "EnhancedDesigner", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer" ]
    ] ],
    [ "EnhancedPointCounter.cs", "_enhanced_point_counter_8cs.html", [
      [ "EnhancedPointCounter", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_point_counter.html", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_point_counter" ]
    ] ],
    [ "FindNodeValidator.cs", "_find_node_validator_8cs.html", [
      [ "FindNodeValidator", "class_finder_1_1_find_node_validator.html", "class_finder_1_1_find_node_validator" ]
    ] ],
    [ "FindSentenceBox.cs", "_find_sentence_box_8cs.html", [
      [ "FindSentenceBox", "class_finder_1_1_find_sentence_box.html", "class_finder_1_1_find_sentence_box" ]
    ] ],
    [ "FindSentenceBox.Designer.cs", "_find_sentence_box_8_designer_8cs.html", [
      [ "FindSentenceBox", "class_finder_1_1_find_sentence_box.html", "class_finder_1_1_find_sentence_box" ]
    ] ],
    [ "FormSize.cs", "_form_size_8cs.html", [
      [ "FormSizeBasic", "class_graph_visualiser_1_1_form_size_basic.html", "class_graph_visualiser_1_1_form_size_basic" ],
      [ "FormSizeEnhanced", "class_graph_visualiser_1_1_form_size_enhanced.html", "class_graph_visualiser_1_1_form_size_enhanced" ]
    ] ],
    [ "GetMenuBasic.cs", "_get_menu_basic_8cs.html", [
      [ "GetMenuBasic", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic" ]
    ] ],
    [ "GetMenuEnhanced.cs", "_get_menu_enhanced_8cs.html", [
      [ "GetMenuEnhanced", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced" ]
    ] ],
    [ "GraphicsSchema.cs", "_graphics_schema_8cs.html", [
      [ "GraphicsSchema", "class_graph_visualiser_1_1_graphics_schema.html", "class_graph_visualiser_1_1_graphics_schema" ]
    ] ],
    [ "IDesigner.cs", "_i_designer_8cs.html", [
      [ "IDesigner", "interface_graph_visualiser_1_1_i_designer.html", "interface_graph_visualiser_1_1_i_designer" ]
    ] ],
    [ "IFinder.cs", "_i_finder_8cs.html", [
      [ "IFinder", "interface_finder_1_1_i_finder.html", "interface_finder_1_1_i_finder" ]
    ] ],
    [ "InsertNewSentenceBox.cs", "_insert_new_sentence_box_8cs.html", [
      [ "InsertNewSentenceBox", "class_conllu_visualiser_1_1_insert_new_sentence_box.html", "class_conllu_visualiser_1_1_insert_new_sentence_box" ]
    ] ],
    [ "InsertNewSentenceBox.Designer.cs", "_insert_new_sentence_box_8_designer_8cs.html", [
      [ "InsertNewSentenceBox", "class_conllu_visualiser_1_1_insert_new_sentence_box.html", "class_conllu_visualiser_1_1_insert_new_sentence_box" ]
    ] ],
    [ "ISentence.cs", "_i_sentence_8cs.html", [
      [ "ISentence", "interface_conllu_visualiser_1_1_i_sentence.html", "interface_conllu_visualiser_1_1_i_sentence" ]
    ] ],
    [ "ITreeWord.cs", "_i_tree_word_8cs.html", [
      [ "ITreeWord", "interface_conllu_visualiser_1_1_i_tree_word.html", "interface_conllu_visualiser_1_1_i_tree_word" ]
    ] ],
    [ "IVisualiser.cs", "_i_visualiser_8cs.html", [
      [ "IVisualiser", "interface_graph_visualiser_1_1_i_visualiser.html", "interface_graph_visualiser_1_1_i_visualiser" ]
    ] ],
    [ "IWord.cs", "_i_word_8cs.html", [
      [ "IWord", "interface_conllu_visualiser_1_1_i_word.html", "interface_conllu_visualiser_1_1_i_word" ]
    ] ],
    [ "ListOfSentences.cs", "_list_of_sentences_8cs.html", [
      [ "ListOfSentences", "class_conllu_visualiser_1_1_list_of_sentences.html", "class_conllu_visualiser_1_1_list_of_sentences" ]
    ] ],
    [ "MultiWord.cs", "_multi_word_8cs.html", [
      [ "MultiWord", "class_conllu_visualiser_1_1_multi_word.html", "class_conllu_visualiser_1_1_multi_word" ]
    ] ],
    [ "NodeFinder.cs", "_node_finder_8cs.html", [
      [ "NodeFinder", "class_finder_1_1_node_finder.html", "class_finder_1_1_node_finder" ]
    ] ],
    [ "Program.cs", "_program_8cs.html", [
      [ "Program", "class_conllu_visualiser_1_1_program.html", "class_conllu_visualiser_1_1_program" ]
    ] ],
    [ "Reader.cs", "_reader_8cs.html", [
      [ "IReader", "interface_conllu_visualiser_1_1_i_reader.html", "interface_conllu_visualiser_1_1_i_reader" ],
      [ "Reader", "class_conllu_visualiser_1_1_reader.html", "class_conllu_visualiser_1_1_reader" ]
    ] ],
    [ "Sentence.cs", "_sentence_8cs.html", [
      [ "Sentence", "class_conllu_visualiser_1_1_sentence.html", "class_conllu_visualiser_1_1_sentence" ]
    ] ],
    [ "SentenceFinder.cs", "_sentence_finder_8cs.html", [
      [ "SentenceFinder", "class_finder_1_1_sentence_finder.html", "class_finder_1_1_sentence_finder" ]
    ] ],
    [ "SentenceInfo.cs", "_sentence_info_8cs.html", [
      [ "SentenceInfo", "class_conllu_visualiser_1_1_sentence_info.html", "class_conllu_visualiser_1_1_sentence_info" ]
    ] ],
    [ "ShortcutKeys.cs", "_shortcut_keys_8cs.html", [
      [ "ShortcutKeys", "class_conllu_visualiser_1_1_shortcut_keys.html", "class_conllu_visualiser_1_1_shortcut_keys" ],
      [ "ShortcutKey", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key" ]
    ] ],
    [ "ShortcutsFieldsForm.cs", "_shortcuts_fields_form_8cs.html", [
      [ "ShortcutsFieldsForm", "class_conllu_visualiser_1_1_shortcuts_fields_form.html", "class_conllu_visualiser_1_1_shortcuts_fields_form" ],
      [ "ItemInWordInfo", "class_conllu_visualiser_1_1_item_in_word_info.html", "class_conllu_visualiser_1_1_item_in_word_info" ]
    ] ],
    [ "ShortcutValidator.cs", "_shortcut_validator_8cs.html", [
      [ "IValidator", "interface_conllu_visualiser_1_1_i_validator.html", "interface_conllu_visualiser_1_1_i_validator" ],
      [ "ShortcutValidator", "class_conllu_visualiser_1_1_shortcut_validator.html", "class_conllu_visualiser_1_1_shortcut_validator" ]
    ] ],
    [ "SimpleFileLoader.cs", "_simple_file_loader_8cs.html", [
      [ "IFileLoader", "interface_conllu_visualiser_1_1_i_file_loader.html", "interface_conllu_visualiser_1_1_i_file_loader" ],
      [ "SimpleFileLoader", "class_conllu_visualiser_1_1_simple_file_loader.html", "class_conllu_visualiser_1_1_simple_file_loader" ]
    ] ],
    [ "SimpleSentencesFactory.cs", "_simple_sentences_factory_8cs.html", [
      [ "ISentenceFactory", "interface_conllu_visualiser_1_1_i_sentence_factory.html", "interface_conllu_visualiser_1_1_i_sentence_factory" ],
      [ "SimpleSentenceFactory", "class_conllu_visualiser_1_1_simple_sentence_factory.html", "class_conllu_visualiser_1_1_simple_sentence_factory" ]
    ] ],
    [ "Visitors.cs", "_visitors_8cs.html", [
      [ "IVisitor", "interface_graph_visualiser_1_1_i_visitor.html", "interface_graph_visualiser_1_1_i_visitor" ],
      [ "IGetMenuVisitor", "interface_graph_visualiser_1_1_i_get_menu_visitor.html", "interface_graph_visualiser_1_1_i_get_menu_visitor" ]
    ] ],
    [ "Visualiser.cs", "_visualiser_8cs.html", [
      [ "Visualiser", "class_graph_visualiser_1_1_visualiser.html", "class_graph_visualiser_1_1_visualiser" ]
    ] ],
    [ "Word.cs", "_word_8cs.html", [
      [ "Word", "class_conllu_visualiser_1_1_word.html", "class_conllu_visualiser_1_1_word" ]
    ] ],
    [ "WordFieldsForm.cs", "_word_fields_form_8cs.html", [
      [ "WordFieldsForm", "class_conllu_visualiser_1_1_word_fields_form.html", "class_conllu_visualiser_1_1_word_fields_form" ]
    ] ],
    [ "WordFieldsForm.Designer.cs", "_word_fields_form_8_designer_8cs.html", [
      [ "WordFieldsForm", "class_conllu_visualiser_1_1_word_fields_form.html", "class_conllu_visualiser_1_1_word_fields_form" ]
    ] ],
    [ "WordInfo.cs", "_word_info_8cs.html", [
      [ "WordInfo", "class_conllu_visualiser_1_1_word_info.html", "class_conllu_visualiser_1_1_word_info" ]
    ] ],
    [ "WordPoint.cs", "_word_point_8cs.html", [
      [ "WordPoint", "class_conllu_visualiser_1_1_word_point.html", "class_conllu_visualiser_1_1_word_point" ]
    ] ]
];