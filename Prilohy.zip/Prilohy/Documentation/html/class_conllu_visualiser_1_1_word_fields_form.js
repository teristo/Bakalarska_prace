var class_conllu_visualiser_1_1_word_fields_form =
[
    [ "WordFieldsForm", "class_conllu_visualiser_1_1_word_fields_form.html#aa8a99e14acf616497038c514b34a4f8c", null ],
    [ "WordFieldsForm", "class_conllu_visualiser_1_1_word_fields_form.html#a8ba7d37fd73873b4fadf2b32a493473a", null ],
    [ "AddDictRows", "class_conllu_visualiser_1_1_word_fields_form.html#ab49f16cb7887e7f46fe64418c05ac577", null ],
    [ "AddRows", "class_conllu_visualiser_1_1_word_fields_form.html#a963db6bd1578e9b299ff5f9b014d4586", null ],
    [ "ChangedValue", "class_conllu_visualiser_1_1_word_fields_form.html#a2a68baaf0e71532d7cd2a79c4e55ffe1", null ],
    [ "Dispose", "class_conllu_visualiser_1_1_word_fields_form.html#adb7cd70165c7d0657060c5378c6ed028", null ],
    [ "GetState", "class_conllu_visualiser_1_1_word_fields_form.html#a60db764bbce8382ad935c9edca63157e", null ],
    [ "InitButton", "class_conllu_visualiser_1_1_word_fields_form.html#a1809ea1321665ed25ef5c255f413b03d", null ],
    [ "InitializeComponent", "class_conllu_visualiser_1_1_word_fields_form.html#af345bf8d44cec6ada2d23ff382af1b24", null ],
    [ "ValidateCell", "class_conllu_visualiser_1_1_word_fields_form.html#a79b700cd30e29698e4d3455997af1852", null ],
    [ "button", "class_conllu_visualiser_1_1_word_fields_form.html#a63d15406160982f08cca9f8b71a5c060", null ],
    [ "components", "class_conllu_visualiser_1_1_word_fields_form.html#a59d216c1c232d4c2ba9981764bced852", null ],
    [ "headers", "class_conllu_visualiser_1_1_word_fields_form.html#ad2bdad2786892fc1d29a85b3ebe289f4", null ],
    [ "labelShortcut", "class_conllu_visualiser_1_1_word_fields_form.html#a63c1de2ba728fc811b2255ed6e32eb9d", null ],
    [ "shortcutPanel", "class_conllu_visualiser_1_1_word_fields_form.html#a3565a436b1cbf4e3e7d10dab2abe077b", null ],
    [ "shortcutTextBox", "class_conllu_visualiser_1_1_word_fields_form.html#a7d0f90b81695476576d0c34a49974dfb", null ],
    [ "table", "class_conllu_visualiser_1_1_word_fields_form.html#ab5d860a65213391f980f92ae1b93997c", null ],
    [ "values", "class_conllu_visualiser_1_1_word_fields_form.html#aca53dc855fd574117e5c5b7f11f942ea", null ],
    [ "Validator", "class_conllu_visualiser_1_1_word_fields_form.html#a660a3635f3209c79a5571f798e59ca0a", null ]
];