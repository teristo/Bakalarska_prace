var interface_conllu_visualiser_1_1_i_sentence_factory =
[
    [ "GetSentence", "interface_conllu_visualiser_1_1_i_sentence_factory.html#ad451fd24f486e3b11946b775d77f8e98", null ]
];