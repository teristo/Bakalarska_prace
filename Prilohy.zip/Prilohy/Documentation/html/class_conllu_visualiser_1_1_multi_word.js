var class_conllu_visualiser_1_1_multi_word =
[
    [ "MultiWord", "class_conllu_visualiser_1_1_multi_word.html#ac6d02992ecdfbc6bca3a3a05932ddf84", null ],
    [ "MultiWord", "class_conllu_visualiser_1_1_multi_word.html#a029acea86ca8b112b482e58b5064aad3", null ],
    [ "Accept", "class_conllu_visualiser_1_1_multi_word.html#ab404fad1ab170bf7afc80a34cbaf776f", null ],
    [ "ActualizeId", "class_conllu_visualiser_1_1_multi_word.html#a512beeb06ca555fea575ae7804d00284", null ],
    [ "AddNotJoinedSubWord", "class_conllu_visualiser_1_1_multi_word.html#a027660ff46f00750695990007e9931f3", null ],
    [ "AddSubWord", "class_conllu_visualiser_1_1_multi_word.html#a0fd8cc29a695244ecbd53fafe830266e", null ],
    [ "CanStartNewSentence", "class_conllu_visualiser_1_1_multi_word.html#a7371b63cdaec313d0f4a57a68a1ae3be", null ],
    [ "Delete", "class_conllu_visualiser_1_1_multi_word.html#a1f1d8d518730b8acb4bf3a034043a75e", null ],
    [ "DeleteSubWord", "class_conllu_visualiser_1_1_multi_word.html#a806a04094098679b4966f0a52fe5ff99", null ],
    [ "GetContextMenu", "class_conllu_visualiser_1_1_multi_word.html#ab9ae9e308206d89a50d2830cba3e9b1f", null ],
    [ "GetFormToSentence", "class_conllu_visualiser_1_1_multi_word.html#adbdefbefecc684fc0468014ed63a1b8f", null ],
    [ "GetMaxLevel", "class_conllu_visualiser_1_1_multi_word.html#a7753f0a515060f9cc10bd3da77fee88f", null ],
    [ "GetSubWord", "class_conllu_visualiser_1_1_multi_word.html#a4d94b69d6a0fa63d89ffddaef19e39ed", null ],
    [ "GetWordPoint", "class_conllu_visualiser_1_1_multi_word.html#aa93583c68687a6a2546e02b71774cb15", null ],
    [ "ShiftId", "class_conllu_visualiser_1_1_multi_word.html#ae44cc4ab545062fd722c34e585d2967d", null ],
    [ "subWords", "class_conllu_visualiser_1_1_multi_word.html#afe9d445731a0ceb0467d5e5f157caef5", null ],
    [ "From", "class_conllu_visualiser_1_1_multi_word.html#afa824b7da627d3101aeea27d5a3cc5a1", null ],
    [ "MinLevel", "class_conllu_visualiser_1_1_multi_word.html#a07ca7efe978f1d176911f763eb001a6c", null ],
    [ "To", "class_conllu_visualiser_1_1_multi_word.html#a4c64debe510bf603a3f42ee812a3c006", null ]
];