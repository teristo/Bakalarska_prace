var class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key =
[
    [ "ShortcutKey", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#a20b79012131d8dd96a18012c2d293e41", null ],
    [ "AddDictAction", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#ad92f0fb665271aa93eee6f11d95f3390", null ],
    [ "MakeKeyFromFile", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#ad966aca773c4cdccb772f6a6a5635798", null ],
    [ "ProcessKey", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#a043ed6226333a22874fcad12784b9523", null ],
    [ "WriteYourself", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#a6c70792f46ac4a73c08f5e13aad2a46f", null ],
    [ "actions", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#afb58660b7784b4698b64d19efa8eb7d6", null ],
    [ "delimAct", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#a9906759b20370c94025a04b2d0766461", null ],
    [ "delimFeatsMisc", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#afd8474c2f2b994c49dc42dcbaf6a63ee", null ],
    [ "deps", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#a97e8270e2df2cf258c880d5318117731", null ],
    [ "feats", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#a8e56bff38787a36748faa8828e717abf", null ],
    [ "misc", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#abe5fdf8cf8b7bbd5567e7e11f5a065eb", null ],
    [ "Shortcut", "class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#ad0210cfd5ecf8b8b570e22948d960f48", null ]
];