var class_conllu_visualiser_1_1_simple_sentence_factory =
[
    [ "SimpleSentenceFactory", "class_conllu_visualiser_1_1_simple_sentence_factory.html#a949ec864e312485684c8b0957f29eb28", null ],
    [ "GetSentence", "class_conllu_visualiser_1_1_simple_sentence_factory.html#afeee10013b914f62a3237a77db5ca534", null ],
    [ "idNum", "class_conllu_visualiser_1_1_simple_sentence_factory.html#a1aeb89f135240eb16ad795f3a9a698fb", null ],
    [ "Reader", "class_conllu_visualiser_1_1_simple_sentence_factory.html#af77eba83c407293bc4f33f8abcddf835", null ]
];