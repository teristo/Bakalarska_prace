var interface_conllu_visualiser_1_1_i_tree_word =
[
    [ "AddChild", "interface_conllu_visualiser_1_1_i_tree_word.html#a87dc0e065720eb2eb7d7f11bd00fd795", null ],
    [ "AddEmptyNode", "interface_conllu_visualiser_1_1_i_tree_word.html#ac0220ab8eda714c22d92cfeb278986cd", null ],
    [ "CanBeParentOf", "interface_conllu_visualiser_1_1_i_tree_word.html#aba7866abd27b60812009d6a1da7c2e2c", null ],
    [ "RemoveChild", "interface_conllu_visualiser_1_1_i_tree_word.html#a610544aaf0383aa983791d4450e5f81a", null ],
    [ "Swap", "interface_conllu_visualiser_1_1_i_tree_word.html#af5cdb63932d287fe4aad72abd306c05b", null ],
    [ "Children", "interface_conllu_visualiser_1_1_i_tree_word.html#a8895e4aae2ced8b0815d4c98b59f8f72", null ],
    [ "EmptyNodes", "interface_conllu_visualiser_1_1_i_tree_word.html#a49033e4d39445213b8245860bb7016bd", null ],
    [ "IsJoined", "interface_conllu_visualiser_1_1_i_tree_word.html#a22809a4ce7af86af4b645a6d257de79c", null ],
    [ "IsRoot", "interface_conllu_visualiser_1_1_i_tree_word.html#aaf4d8ff67f56a5791bb0a850701f7efb", null ],
    [ "JoinedWord", "interface_conllu_visualiser_1_1_i_tree_word.html#a6b764205a87d02d5d36c9bf0c164fe14", null ],
    [ "Parent", "interface_conllu_visualiser_1_1_i_tree_word.html#ab99da6e2e152a73a9f820d4576f4c08f", null ]
];