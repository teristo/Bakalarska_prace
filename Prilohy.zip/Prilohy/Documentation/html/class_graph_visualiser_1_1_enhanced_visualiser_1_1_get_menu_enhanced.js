var class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced =
[
    [ "AddToMultiword", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a07f852854ea8515265a1c3c97af22364", null ],
    [ "GetMenu", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#acd4e2fef127f289d77ae8021ba0c5b77", null ],
    [ "GetMenu", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a82540f2346fa3b616d244c8df6801c9e", null ],
    [ "GetNextNotEmpty", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a01059f9427738e7babe0137bf6089159", null ],
    [ "InsertEmptyAfter", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#ad68f0fb7da0a96ebc9a420ab9cac151f", null ],
    [ "JoinedMenu", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a4dcdd9a479f47ed5271abdc7f0626a95", null ],
    [ "MakeMultiword", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#af1467b71adc0b697692f8784f18ebc9c", null ],
    [ "RemoveMultiword", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a0a27a921876126237f80a9fd6acb215e", null ],
    [ "ShowInfoMultiword", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a490a0dd7c1c60b933f6a11daca56f68e", null ],
    [ "SwapWithNextEmpty", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a2ed1bb34a4d23212b08f2c8792ea5a1b", null ]
];