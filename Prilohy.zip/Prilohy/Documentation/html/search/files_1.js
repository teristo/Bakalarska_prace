var searchData=
[
  ['basicdesigner_2ecs',['BasicDesigner.cs',['../_basic_designer_8cs.html',1,'']]],
  ['basicpointcounter_2ecs',['BasicPointCounter.cs',['../_basic_point_counter_8cs.html',1,'']]],
  ['basicword_2ecs',['BasicWord.cs',['../_basic_word_8cs.html',1,'']]]
];
