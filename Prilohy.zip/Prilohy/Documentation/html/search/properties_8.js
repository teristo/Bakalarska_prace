var searchData=
[
  ['id',['Id',['../interface_conllu_visualiser_1_1_i_word.html#a87a72cb1afc4af91d9a60386b8bd9bb6',1,'ConlluVisualiser.IWord.Id()'],['../class_conllu_visualiser_1_1_word.html#a2bc416872c14ce27cdfd74027b7ae5a7',1,'ConlluVisualiser.Word.Id()'],['../class_conllu_visualiser_1_1_word_info.html#a42c40b527bc783025bc960aa734d7132',1,'ConlluVisualiser.WordInfo.Id()']]],
  ['ids_5fon_5fpanel',['Ids_on_panel',['../class_conllu_visualiser_1_1_list_of_sentences.html#ad1bdc5e812f7e419d2761eed2a5e183a',1,'ConlluVisualiser::ListOfSentences']]],
  ['info',['Info',['../interface_conllu_visualiser_1_1_i_word.html#afe4051bb6e6e1eaed1986a6b10dd31f6',1,'ConlluVisualiser.IWord.Info()'],['../class_conllu_visualiser_1_1_sentence_info.html#a6f854d96470d23318a2fefae7fbd41d8',1,'ConlluVisualiser.SentenceInfo.Info()'],['../class_conllu_visualiser_1_1_word.html#a1567e058a3b4854c53e97f315419fe09',1,'ConlluVisualiser.Word.Info()']]],
  ['isactive',['IsActive',['../interface_conllu_visualiser_1_1_i_word.html#aeff0ef97bbcdbd77529f9cae62d4d50a',1,'ConlluVisualiser.IWord.IsActive()'],['../class_conllu_visualiser_1_1_word.html#a7413d5c5fe3a2ce67340809841ba48dd',1,'ConlluVisualiser.Word.IsActive()']]],
  ['isempty',['IsEmpty',['../class_conllu_visualiser_1_1_conllu_sentence_factory_1_1_one_sentence_parts.html#afb7cf59031424913eb98814000ca1521',1,'ConlluVisualiser::ConlluSentenceFactory::OneSentenceParts']]],
  ['isjoined',['IsJoined',['../interface_conllu_visualiser_1_1_i_tree_word.html#a22809a4ce7af86af4b645a6d257de79c',1,'ConlluVisualiser::ITreeWord']]],
  ['isroot',['IsRoot',['../class_conllu_visualiser_1_1_basic_word.html#a67e491c6a9893770ba127ca92bbf29d8',1,'ConlluVisualiser.BasicWord.IsRoot()'],['../interface_conllu_visualiser_1_1_i_tree_word.html#aaf4d8ff67f56a5791bb0a850701f7efb',1,'ConlluVisualiser.ITreeWord.IsRoot()']]]
];
