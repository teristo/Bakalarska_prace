var searchData=
[
  ['changedsentences',['ChangedSentences',['../class_conllu_visualiser_1_1_list_of_sentences.html#a2e62da1934354f95e8b217ba0b1c489b',1,'ConlluVisualiser::ListOfSentences']]],
  ['children',['Children',['../class_conllu_visualiser_1_1_basic_word.html#a1d55d998a0c7fdd90a6668279e21800c',1,'ConlluVisualiser.BasicWord.Children()'],['../interface_conllu_visualiser_1_1_i_tree_word.html#a8895e4aae2ced8b0815d4c98b59f8f72',1,'ConlluVisualiser.ITreeWord.Children()']]],
  ['childrenenhanced',['ChildrenEnhanced',['../interface_conllu_visualiser_1_1_i_word.html#afb3e23b73aa40fdebf569a00585f7501',1,'ConlluVisualiser.IWord.ChildrenEnhanced()'],['../class_conllu_visualiser_1_1_word.html#a66b19593b8a1951aeacef5dbd8576fb7',1,'ConlluVisualiser.Word.ChildrenEnhanced()']]],
  ['colorofactivenode',['ColorOfActiveNode',['../class_graph_visualiser_1_1_graphics_schema.html#ab61271aa079bd88c57e18dda0ab62ac1',1,'GraphVisualiser::GraphicsSchema']]],
  ['colorofgraph',['ColorOfGraph',['../class_graph_visualiser_1_1_graphics_schema.html#a8f72bf98296b88ec56b4a17da6c4d017',1,'GraphVisualiser::GraphicsSchema']]],
  ['contextmenugetter',['ContextMenuGetter',['../class_graph_visualiser_1_1_basic_visualiser_1_1_basic_designer.html#a1793fdc5199ccb85a94ea81e43bde72f',1,'GraphVisualiser::BasicVisualiser::BasicDesigner']]],
  ['countwords',['CountWords',['../interface_conllu_visualiser_1_1_i_sentence.html#accde4230ea63bfe152fa4e97272a47c7',1,'ConlluVisualiser.ISentence.CountWords()'],['../class_conllu_visualiser_1_1_sentence.html#ab82d06e485195f4f96f699d33d639715',1,'ConlluVisualiser.Sentence.CountWords()']]]
];
