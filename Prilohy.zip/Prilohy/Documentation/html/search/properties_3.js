var searchData=
[
  ['depfont',['DepFont',['../class_graph_visualiser_1_1_graphics_schema.html#acc2870b554848d3bf9d29f4027346742',1,'GraphVisualiser::GraphicsSchema']]],
  ['deprel',['Deprel',['../class_conllu_visualiser_1_1_word_info.html#aa87d5eb3ca16bd6cc17b56a3339d774e',1,'ConlluVisualiser::WordInfo']]],
  ['deps',['Deps',['../class_conllu_visualiser_1_1_word_info.html#a399c390ce5959f8a6ff4b5825d64eb10',1,'ConlluVisualiser::WordInfo']]]
];
