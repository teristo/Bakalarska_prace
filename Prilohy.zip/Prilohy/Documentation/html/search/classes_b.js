var searchData=
[
  ['onesentenceparts',['OneSentenceParts',['../class_conllu_visualiser_1_1_conllu_sentence_factory_1_1_one_sentence_parts.html',1,'ConlluVisualiser::ConlluSentenceFactory']]]
];
