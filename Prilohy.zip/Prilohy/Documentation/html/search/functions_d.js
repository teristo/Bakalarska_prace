var searchData=
[
  ['okbutton_5fclick',['OKButton_Click',['../class_finder_1_1_find_sentence_box.html#a326c066488d56aefb99c54fa93682db3',1,'Finder::FindSentenceBox']]]
];
