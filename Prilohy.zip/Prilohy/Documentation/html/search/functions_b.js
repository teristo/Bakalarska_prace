var searchData=
[
  ['main',['Main',['../class_conllu_visualiser_1_1_program.html#a4fb6ca4fe7322bd6a11eff42f49b52ae',1,'ConlluVisualiser::Program']]],
  ['makekeyfromfile',['MakeKeyFromFile',['../class_conllu_visualiser_1_1_shortcut_keys_1_1_shortcut_key.html#ad966aca773c4cdccb772f6a6a5635798',1,'ConlluVisualiser::ShortcutKeys::ShortcutKey']]],
  ['makemultiword',['MakeMultiword',['../class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#af1467b71adc0b697692f8784f18ebc9c',1,'GraphVisualiser::EnhancedVisualiser::GetMenuEnhanced']]],
  ['makenewlistofsentences',['MakeNewListOfSentences',['../class_conllu_visualiser_1_1_app_form.html#ad8138d56bb1d7bd7d9476d5a23aad6d2',1,'ConlluVisualiser::AppForm']]],
  ['makenewsentence',['MakeNewSentence',['../class_conllu_visualiser_1_1_list_of_sentences.html#a1700e135191d3d5e51d1ff5f62105f84',1,'ConlluVisualiser::ListOfSentences']]],
  ['makepagebutton',['MakePageButton',['../class_conllu_visualiser_1_1_list_of_sentences.html#adcc6a3fc0af5a7949114c468da6e2aac',1,'ConlluVisualiser::ListOfSentences']]],
  ['makereadonly',['MakeReadonly',['../class_conllu_visualiser_1_1_conllu_validator.html#aae2d4a4f779d923769cba6bf74ba4bb7',1,'ConlluVisualiser.ConlluValidator.MakeReadonly()'],['../class_finder_1_1_find_node_validator.html#a6cf17d7e680e4f53cb3681cf310f2d14',1,'Finder.FindNodeValidator.MakeReadonly()'],['../interface_conllu_visualiser_1_1_i_validator.html#a1716859aea4dac972c29afeaacb7c4b8',1,'ConlluVisualiser.IValidator.MakeReadonly()'],['../class_conllu_visualiser_1_1_shortcut_validator.html#ab38c17a9a91fcfea1e08acae3a73c31b',1,'ConlluVisualiser.ShortcutValidator.MakeReadonly()']]],
  ['makesentencelinkbutton',['MakeSentenceLinkButton',['../class_conllu_visualiser_1_1_list_of_sentences.html#af6139cd556381b3a2e974ebc79327025',1,'ConlluVisualiser::ListOfSentences']]],
  ['maketext',['MakeText',['../interface_conllu_visualiser_1_1_i_sentence.html#af13447044de9bd95acabafc8671b0b80',1,'ConlluVisualiser.ISentence.MakeText()'],['../class_conllu_visualiser_1_1_sentence.html#ac46480b4f12e68e5d759513ce808c366',1,'ConlluVisualiser.Sentence.MakeText()']]],
  ['matchpoint',['MatchPoint',['../class_conllu_visualiser_1_1_word_point.html#a01fc11c9f1ae4c8f2610f1fa701376d6',1,'ConlluVisualiser::WordPoint']]],
  ['multiword',['MultiWord',['../class_conllu_visualiser_1_1_multi_word.html#ac6d02992ecdfbc6bca3a3a05932ddf84',1,'ConlluVisualiser.MultiWord.MultiWord(string word, string id)'],['../class_conllu_visualiser_1_1_multi_word.html#a029acea86ca8b112b482e58b5064aad3',1,'ConlluVisualiser.MultiWord.MultiWord(IWord first, IWord second, ISentence sentence)']]]
];
