var searchData=
[
  ['multiword',['MultiWord',['../class_conllu_visualiser_1_1_multi_word.html',1,'ConlluVisualiser']]]
];
