var searchData=
[
  ['findnodevalidator_2ecs',['FindNodeValidator.cs',['../_find_node_validator_8cs.html',1,'']]],
  ['findsentencebox_2ecs',['FindSentenceBox.cs',['../_find_sentence_box_8cs.html',1,'']]],
  ['findsentencebox_2edesigner_2ecs',['FindSentenceBox.Designer.cs',['../_find_sentence_box_8_designer_8cs.html',1,'']]],
  ['formsize_2ecs',['FormSize.cs',['../_form_size_8cs.html',1,'']]]
];
