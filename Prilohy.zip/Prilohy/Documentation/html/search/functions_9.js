var searchData=
[
  ['joinallpoints',['JoinAllPoints',['../class_graph_visualiser_1_1_basic_visualiser_1_1_draw_word_basic.html#a4ef481c5b497a7a18d225b69d7deac14',1,'GraphVisualiser::BasicVisualiser::DrawWordBasic']]],
  ['joinedmenu',['JoinedMenu',['../class_graph_visualiser_1_1_enhanced_visualiser_1_1_get_menu_enhanced.html#a4dcdd9a479f47ed5271abdc7f0626a95',1,'GraphVisualiser::EnhancedVisualiser::GetMenuEnhanced']]],
  ['joinsentences',['JoinSentences',['../class_conllu_visualiser_1_1_list_of_sentences.html#a61e6a7b4aebd08d695bf31563e177f62',1,'ConlluVisualiser::ListOfSentences']]]
];
