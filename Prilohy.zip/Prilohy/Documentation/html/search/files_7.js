var searchData=
[
  ['idesigner_2ecs',['IDesigner.cs',['../_i_designer_8cs.html',1,'']]],
  ['ifinder_2ecs',['IFinder.cs',['../_i_finder_8cs.html',1,'']]],
  ['index_2emd',['index.md',['../index_8md.html',1,'']]],
  ['insertnewsentencebox_2ecs',['InsertNewSentenceBox.cs',['../_insert_new_sentence_box_8cs.html',1,'']]],
  ['insertnewsentencebox_2edesigner_2ecs',['InsertNewSentenceBox.Designer.cs',['../_insert_new_sentence_box_8_designer_8cs.html',1,'']]],
  ['isentence_2ecs',['ISentence.cs',['../_i_sentence_8cs.html',1,'']]],
  ['itreeword_2ecs',['ITreeWord.cs',['../_i_tree_word_8cs.html',1,'']]],
  ['ivisualiser_2ecs',['IVisualiser.cs',['../_i_visualiser_8cs.html',1,'']]],
  ['iword_2ecs',['IWord.cs',['../_i_word_8cs.html',1,'']]]
];
