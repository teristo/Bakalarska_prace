var searchData=
[
  ['head',['Head',['../class_conllu_visualiser_1_1_word_info.html#ac53a7af8ad879addcb401850a7f928fa',1,'ConlluVisualiser::WordInfo']]]
];
