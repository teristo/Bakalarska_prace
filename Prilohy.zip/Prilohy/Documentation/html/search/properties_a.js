var searchData=
[
  ['lastfoundsentence',['LastFoundSentence',['../class_finder_1_1_node_finder.html#ab949bb82149c798c68f29ec96d99cb35',1,'Finder.NodeFinder.LastFoundSentence()'],['../class_finder_1_1_sentence_finder.html#aa09ecdb6d1f134e59fd6f7476cf9f95c',1,'Finder.SentenceFinder.LastFoundSentence()']]],
  ['lastwordindex',['LastWordIndex',['../class_finder_1_1_node_finder.html#a663d843cdde7f930e1ca39678f21bf57',1,'Finder::NodeFinder']]],
  ['leftspace',['LeftSpace',['../class_graph_visualiser_1_1_basic_visualiser_1_1_basic_point_counter.html#ae179efb4170ad6fc4dd04fd0378124f5',1,'GraphVisualiser::BasicVisualiser::BasicPointCounter']]],
  ['lemma',['Lemma',['../class_conllu_visualiser_1_1_word_info.html#a9a2c9ea6c4818ce75025aa42aae10a7b',1,'ConlluVisualiser::WordInfo']]],
  ['level',['Level',['../class_conllu_visualiser_1_1_word_point.html#a25f44a4b1ea568a7b8106c2a8971bc7d',1,'ConlluVisualiser::WordPoint']]],
  ['leveldifference',['LevelDifference',['../class_graph_visualiser_1_1_basic_visualiser_1_1_basic_point_counter.html#a3999496ee9b97f56694e5977b5c24ac9',1,'GraphVisualiser::BasicVisualiser::BasicPointCounter']]],
  ['linepen',['LinePen',['../class_graph_visualiser_1_1_graphics_schema.html#a6154a739d17218b5a63251f47bcbbc82',1,'GraphVisualiser::GraphicsSchema']]]
];
