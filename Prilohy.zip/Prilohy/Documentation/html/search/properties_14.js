var searchData=
[
  ['worddrawer',['WordDrawer',['../class_graph_visualiser_1_1_basic_visualiser_1_1_basic_designer.html#ac258cf1e43acd1dce0adf65e6a4cde78',1,'GraphVisualiser::BasicVisualiser::BasicDesigner']]],
  ['words',['Words',['../class_conllu_visualiser_1_1_conllu_sentence_factory_1_1_one_sentence_parts.html#ad6e704aa587c27e77d5c1c111cd4610a',1,'ConlluVisualiser::ConlluSentenceFactory::OneSentenceParts']]]
];
