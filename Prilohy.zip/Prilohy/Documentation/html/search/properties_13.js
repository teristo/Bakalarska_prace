var searchData=
[
  ['validator',['Validator',['../class_conllu_visualiser_1_1_word_fields_form.html#a660a3635f3209c79a5571f798e59ca0a',1,'ConlluVisualiser::WordFieldsForm']]],
  ['value',['Value',['../class_conllu_visualiser_1_1_item_in_word_info.html#af8c56577052bf0c135f012c1ecfbec98',1,'ConlluVisualiser::ItemInWordInfo']]]
];
