var searchData=
[
  ['tableroot',['TableRoot',['../class_conllu_visualiser_1_1_sentence_info.html#adc34043a3b92c36ee25dabc0d317bdb1',1,'ConlluVisualiser::SentenceInfo']]],
  ['text_5fattribute',['Text_attribute',['../interface_conllu_visualiser_1_1_i_sentence.html#ab322ebde512fe6a5617014e3a24130ed',1,'ConlluVisualiser.ISentence.Text_attribute()'],['../class_conllu_visualiser_1_1_sentence.html#aa937af0f9f19af0233707931017ee09e',1,'ConlluVisualiser.Sentence.Text_attribute()']]],
  ['to',['To',['../class_conllu_visualiser_1_1_multi_word.html#a4c64debe510bf603a3f42ee812a3c006',1,'ConlluVisualiser::MultiWord']]]
];
