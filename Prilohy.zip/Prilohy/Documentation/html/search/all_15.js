var searchData=
[
  ['x',['X',['../class_conllu_visualiser_1_1_word_point.html#ac94460522ade3e2b22139bfda61bb70b',1,'ConlluVisualiser::WordPoint']]],
  ['xpos',['Xpos',['../class_conllu_visualiser_1_1_word_info.html#ab91102369bdd41988a7e39342d9e1ddf',1,'ConlluVisualiser::WordInfo']]]
];
