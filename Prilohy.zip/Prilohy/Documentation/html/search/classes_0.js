var searchData=
[
  ['appform',['AppForm',['../class_conllu_visualiser_1_1_app_form.html',1,'ConlluVisualiser']]]
];
