var searchData=
[
  ['heightofsubtrees',['HeightOfSubtrees',['../class_graph_visualiser_1_1_basic_visualiser_1_1_basic_point_counter.html#afe27d6fa101e1df5cfe2121d0463bd0b',1,'GraphVisualiser::BasicVisualiser::BasicPointCounter']]]
];
