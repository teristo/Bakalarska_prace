var searchData=
[
  ['listofsentences_2ecs',['ListOfSentences.cs',['../_list_of_sentences_8cs.html',1,'']]]
];
