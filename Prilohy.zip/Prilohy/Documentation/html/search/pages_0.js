var searchData=
[
  ['this_20is_20the_20_3cstrong_3ehomepage_3c_2fstrong_3e_2e',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__c_1__users__terezka__documents__visual__studio_2017__projects__bakalarka__year_project_index.html',1,'']]]
];
