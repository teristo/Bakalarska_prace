var searchData=
[
  ['name',['Name',['../class_conllu_visualiser_1_1_item_in_word_info.html#a3cb5cc4bc915010bb5cba634fcb90428',1,'ConlluVisualiser::ItemInWordInfo']]],
  ['nameofsaved',['NameOfSaved',['../class_conllu_visualiser_1_1_app_form.html#aa5d2adaab7c05a4ffff39036c785e435',1,'ConlluVisualiser::AppForm']]],
  ['newfiletoolstripmenuitem',['newFileToolStripMenuItem',['../class_conllu_visualiser_1_1_app_form.html#aeff0c95d69a01c9820bf2fb648ff45e5',1,'ConlluVisualiser::AppForm']]],
  ['newfiletoolstripmenuitem_5fclick',['NewFileToolStripMenuItem_Click',['../class_conllu_visualiser_1_1_app_form.html#a0c7d78228e535e9f49d2d1bd72cb1758',1,'ConlluVisualiser::AppForm']]],
  ['newgraphics',['NewGraphics',['../interface_graph_visualiser_1_1_i_visualiser.html#ab47c6f59008c33814c3ce1139105e8cf',1,'GraphVisualiser.IVisualiser.NewGraphics()'],['../class_graph_visualiser_1_1_visualiser.html#aea966e01c45a510487d09e1a5791dbcd',1,'GraphVisualiser.Visualiser.NewGraphics()']]],
  ['newpoints',['NewPoints',['../class_graph_visualiser_1_1_basic_visualiser_1_1_basic_designer.html#a5d24642c9510870518d137a5a6ac28a6',1,'GraphVisualiser.BasicVisualiser.BasicDesigner.NewPoints()'],['../class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#a6ac2c798bd138daadaf1070918354bc7',1,'GraphVisualiser.EnhancedVisualiser.EnhancedDesigner.NewPoints()'],['../interface_graph_visualiser_1_1_i_designer.html#a95dbbaf90652f4c7e5636549f6b78100',1,'GraphVisualiser.IDesigner.NewPoints()']]],
  ['nodefinder',['NodeFinder',['../class_finder_1_1_node_finder.html',1,'Finder.NodeFinder'],['../class_finder_1_1_node_finder.html#a9bdbe0db56e957a47c62852d29abb2e5',1,'Finder.NodeFinder.NodeFinder()']]],
  ['nodefinder_2ecs',['NodeFinder.cs',['../_node_finder_8cs.html',1,'']]]
];
