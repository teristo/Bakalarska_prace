var searchData=
[
  ['listofsentences',['ListOfSentences',['../class_conllu_visualiser_1_1_list_of_sentences.html',1,'ConlluVisualiser']]]
];
