var searchData=
[
  ['reader',['Reader',['../class_conllu_visualiser_1_1_reader.html',1,'ConlluVisualiser']]]
];
