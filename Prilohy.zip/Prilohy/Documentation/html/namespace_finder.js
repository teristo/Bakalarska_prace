var namespace_finder =
[
    [ "FindNodeValidator", "class_finder_1_1_find_node_validator.html", "class_finder_1_1_find_node_validator" ],
    [ "FindSentenceBox", "class_finder_1_1_find_sentence_box.html", "class_finder_1_1_find_sentence_box" ],
    [ "IFinder", "interface_finder_1_1_i_finder.html", "interface_finder_1_1_i_finder" ],
    [ "NodeFinder", "class_finder_1_1_node_finder.html", "class_finder_1_1_node_finder" ],
    [ "SentenceFinder", "class_finder_1_1_sentence_finder.html", "class_finder_1_1_sentence_finder" ]
];