var namespaces_dup =
[
    [ "ConlluVisualiser", "namespace_conllu_visualiser.html", null ],
    [ "Finder", "namespace_finder.html", null ],
    [ "GraphVisualiser", "namespace_graph_visualiser.html", "namespace_graph_visualiser" ]
];