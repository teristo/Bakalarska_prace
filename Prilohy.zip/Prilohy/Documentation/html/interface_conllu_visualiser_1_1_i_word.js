var interface_conllu_visualiser_1_1_i_word =
[
    [ "Accept", "interface_conllu_visualiser_1_1_i_word.html#aad59162c97674df96e7c46129881cf67", null ],
    [ "CanStartNewSentence", "interface_conllu_visualiser_1_1_i_word.html#a826ea69fe35dbee1217b9e9d5b0727b7", null ],
    [ "Delete", "interface_conllu_visualiser_1_1_i_word.html#aa5dddd52efc406c0a4691e874a4ba38c", null ],
    [ "GetContextMenu", "interface_conllu_visualiser_1_1_i_word.html#ae4579bf40d5480d967ec003026c206c5", null ],
    [ "GetFormToSentence", "interface_conllu_visualiser_1_1_i_word.html#a4a5065293bf7858b74689aaeabc2955e", null ],
    [ "GetWordBasicInfo", "interface_conllu_visualiser_1_1_i_word.html#a6abc23050369b54fe5f9d8bb416fb4fe", null ],
    [ "GetWordPoint", "interface_conllu_visualiser_1_1_i_word.html#a6402ef7186f84b645e95da0d8c916ba2", null ],
    [ "RemoveChildEnhhanced", "interface_conllu_visualiser_1_1_i_word.html#a67a98dde3426affc73c874c17d0e4bb1", null ],
    [ "SaveToFile", "interface_conllu_visualiser_1_1_i_word.html#ae90a763c9792a44bf4712874d63da867", null ],
    [ "ShiftId", "interface_conllu_visualiser_1_1_i_word.html#a1c2a854952ed75a49bbe99da8018dc85", null ],
    [ "ShowInfo", "interface_conllu_visualiser_1_1_i_word.html#a6f2c518538c295984a54daee2c9a4ef9", null ],
    [ "ChildrenEnhanced", "interface_conllu_visualiser_1_1_i_word.html#afb3e23b73aa40fdebf569a00585f7501", null ],
    [ "Id", "interface_conllu_visualiser_1_1_i_word.html#a87a72cb1afc4af91d9a60386b8bd9bb6", null ],
    [ "Info", "interface_conllu_visualiser_1_1_i_word.html#afe4051bb6e6e1eaed1986a6b10dd31f6", null ],
    [ "IsActive", "interface_conllu_visualiser_1_1_i_word.html#aeff0ef97bbcdbd77529f9cae62d4d50a", null ]
];