var class_conllu_visualiser_1_1_encoding_decoder =
[
    [ "DetectUtf8Encoding", "class_conllu_visualiser_1_1_encoding_decoder.html#ae16aa97be170073988956b2ac94c2535", null ],
    [ "GetFileEncoding", "class_conllu_visualiser_1_1_encoding_decoder.html#a4b51643e8d6eb879fe451392e34d690d", null ],
    [ "StartsBy10", "class_conllu_visualiser_1_1_encoding_decoder.html#a03a3b5a2d874cd9547bc9abe657a3fc8", null ]
];