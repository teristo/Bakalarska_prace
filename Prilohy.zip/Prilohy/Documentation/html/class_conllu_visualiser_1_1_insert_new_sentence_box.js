var class_conllu_visualiser_1_1_insert_new_sentence_box =
[
    [ "InsertNewSentenceBox", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#abd34f7b2ffeca6638d387a9768a1ccd8", null ],
    [ "Dispose", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a7011d2f2f2081f6dca604b549254bc1a", null ],
    [ "GetIdBox", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a76b4614a42145aeb62067637c8d20ae3", null ],
    [ "GetSentence", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a384aa7699ed37511a7298d0723e425b1", null ],
    [ "InitializeComponent", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#acdc8972926aff314a8179ad828be052c", null ],
    [ "Submit", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#ad84d0d696579c2d7f039a9a61e8f981a", null ],
    [ "components", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a611dfd496269bc9120c954e2d6a6e161", null ],
    [ "flowPanel", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a3723e9ec98c50aac0d231f0d8321f129", null ],
    [ "idBox", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a058b288488eb57ccb04df0c0f93b493b", null ],
    [ "legendId", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#ab2ec31b1e9b7e27ad3126d301b4e3e66", null ],
    [ "LegendSent", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a778e3e50a1cd2873ac30b1b43ae177d1", null ],
    [ "OKButton", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a22ecab3df8d2391f613bf2b6cec21aaa", null ],
    [ "sentBox", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#aabe71fbde846b70be4a311615803c2df", null ],
    [ "Sentences", "class_conllu_visualiser_1_1_insert_new_sentence_box.html#a29649c86ba3101c61640464e8e7d1110", null ]
];