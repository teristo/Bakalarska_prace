var class_conllu_visualiser_1_1_current_state =
[
    [ "CurrentState", "class_conllu_visualiser_1_1_current_state.html#aff03b95f1ae1678085fa746672ee55d3", null ],
    [ "ChangeActiveSentence", "class_conllu_visualiser_1_1_current_state.html#a5e02d7bf17d9772a22d70948a6b5636e", null ],
    [ "ChangeActiveWord", "class_conllu_visualiser_1_1_current_state.html#aafc534a7cbbf9baa8b52a5bf590663cc", null ],
    [ "VisualiseNewGraph", "class_conllu_visualiser_1_1_current_state.html#a7cd1e56b1b16b2d1f8467b41252aa15c", null ],
    [ "MainForm", "class_conllu_visualiser_1_1_current_state.html#ad985e4a2764fcefb251e654e3c5e5798", null ],
    [ "ActiveWord", "class_conllu_visualiser_1_1_current_state.html#aaec6469ca053bec161a676ebe749443c", null ]
];