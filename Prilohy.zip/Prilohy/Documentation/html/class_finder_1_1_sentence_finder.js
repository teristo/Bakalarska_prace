var class_finder_1_1_sentence_finder =
[
    [ "SentenceFinder", "class_finder_1_1_sentence_finder.html#ad11e82058f5fd0eb0371d87cef53a94e", null ],
    [ "Find", "class_finder_1_1_sentence_finder.html#a5ff498d6fec3bd4e4dd1991ae9a6e0d1", null ],
    [ "FindFirstSentenceFromIndex", "class_finder_1_1_sentence_finder.html#a34240133df83eef2307c650e360b3f1c", null ],
    [ "FindNextSentence", "class_finder_1_1_sentence_finder.html#af3f9188f0a1f4f38c9fb3457266da646", null ],
    [ "GetFirstSentenceAccordingToParams", "class_finder_1_1_sentence_finder.html#aa282f8d539f98c1a412392c5c715a412", null ],
    [ "Form", "class_finder_1_1_sentence_finder.html#acf59e2e3d230038239f688df520df346", null ],
    [ "LastFoundSentence", "class_finder_1_1_sentence_finder.html#aa09ecdb6d1f134e59fd6f7476cf9f95c", null ],
    [ "Sentence", "class_finder_1_1_sentence_finder.html#afc9b3eec9443450c978e9eb1647de12b", null ],
    [ "Sentences", "class_finder_1_1_sentence_finder.html#a88aa229558477f7dd1b06a3bbea11cb6", null ]
];