var class_conllu_visualiser_1_1_shortcuts_fields_form =
[
    [ "ShortcutsFieldsForm", "class_conllu_visualiser_1_1_shortcuts_fields_form.html#a36c16701bfc253bdebf36b7aafa2aa40", null ],
    [ "GetResult", "class_conllu_visualiser_1_1_shortcuts_fields_form.html#a174e8ada5181626968834198aae51dc6", null ],
    [ "GetShortcutKeys", "class_conllu_visualiser_1_1_shortcuts_fields_form.html#a167a3a34ad4083b31ddd6cb1a290f281", null ],
    [ "ProcessCmdKey", "class_conllu_visualiser_1_1_shortcuts_fields_form.html#a1dd8e671f2bd540639a7dc95cb88c53f", null ],
    [ "SaveState", "class_conllu_visualiser_1_1_shortcuts_fields_form.html#a412a27e60d3f07a0b21e88480d634da7", null ],
    [ "Result", "class_conllu_visualiser_1_1_shortcuts_fields_form.html#aba501609575c533ee019b89e5ec46259", null ],
    [ "ShortcutKeys", "class_conllu_visualiser_1_1_shortcuts_fields_form.html#a27bf5da5752a0e786a0c0a51c37223eb", null ]
];