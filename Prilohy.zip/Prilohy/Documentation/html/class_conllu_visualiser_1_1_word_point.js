var class_conllu_visualiser_1_1_word_point =
[
    [ "GetPoint", "class_conllu_visualiser_1_1_word_point.html#a37a21523782813fd5bc20d8314eb38d9", null ],
    [ "MatchPoint", "class_conllu_visualiser_1_1_word_point.html#a01fc11c9f1ae4c8f2610f1fa701376d6", null ],
    [ "SetPoint", "class_conllu_visualiser_1_1_word_point.html#ae6ba95b79632866dd240b8b95deca0bb", null ],
    [ "point", "class_conllu_visualiser_1_1_word_point.html#a2ad39868b623c9041b133324d5930385", null ],
    [ "Level", "class_conllu_visualiser_1_1_word_point.html#a25f44a4b1ea568a7b8106c2a8971bc7d", null ],
    [ "X", "class_conllu_visualiser_1_1_word_point.html#ac94460522ade3e2b22139bfda61bb70b", null ],
    [ "Y", "class_conllu_visualiser_1_1_word_point.html#a3158fdc3b48ef537b7d2662a27762bdb", null ]
];