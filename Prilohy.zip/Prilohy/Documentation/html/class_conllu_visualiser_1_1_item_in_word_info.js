var class_conllu_visualiser_1_1_item_in_word_info =
[
    [ "ItemInWordInfo", "class_conllu_visualiser_1_1_item_in_word_info.html#a22090d3bc3d1b898b2cee5c02df5b338", null ],
    [ "Name", "class_conllu_visualiser_1_1_item_in_word_info.html#a3cb5cc4bc915010bb5cba634fcb90428", null ],
    [ "Overwrite", "class_conllu_visualiser_1_1_item_in_word_info.html#a6af2f0a9e6edc3aa21d04070ff9cbfd5", null ],
    [ "Value", "class_conllu_visualiser_1_1_item_in_word_info.html#af8c56577052bf0c135f012c1ecfbec98", null ]
];