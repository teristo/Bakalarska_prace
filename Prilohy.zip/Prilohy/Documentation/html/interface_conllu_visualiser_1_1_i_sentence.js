var interface_conllu_visualiser_1_1_i_sentence =
[
    [ "AddWord", "interface_conllu_visualiser_1_1_i_sentence.html#a1adf406e4ea1d304ce9a9321b1f6c84b", null ],
    [ "DeleteWord", "interface_conllu_visualiser_1_1_i_sentence.html#a84b743758afc1a66779999b51015e7ac", null ],
    [ "GetIndexOf", "interface_conllu_visualiser_1_1_i_sentence.html#a242e3ba53c1290dd6f0bd4b48633a949", null ],
    [ "GetWord", "interface_conllu_visualiser_1_1_i_sentence.html#abc6ad68b2a34d99c67bc0f53b3e66cb5", null ],
    [ "GetWord", "interface_conllu_visualiser_1_1_i_sentence.html#ac02d321f2d6d0ba898fb75ae4b8840fe", null ],
    [ "InsertChild", "interface_conllu_visualiser_1_1_i_sentence.html#ac4b958cbce6ee4d8751edaa77786d4ee", null ],
    [ "MakeText", "interface_conllu_visualiser_1_1_i_sentence.html#af13447044de9bd95acabafc8671b0b80", null ],
    [ "SaveTo", "interface_conllu_visualiser_1_1_i_sentence.html#ab2788110cd55bda0ad90922157d3d31b", null ],
    [ "ShowInfo", "interface_conllu_visualiser_1_1_i_sentence.html#a5f476e522a64b1eb2f2218ab9f8b2a74", null ],
    [ "Split", "interface_conllu_visualiser_1_1_i_sentence.html#a94d495c0053b18d8b178e2c03ffa1b9e", null ],
    [ "Swap", "interface_conllu_visualiser_1_1_i_sentence.html#a0849be52116e5cb6cdb6c2b81dd9cabc", null ],
    [ "CountWords", "interface_conllu_visualiser_1_1_i_sentence.html#accde4230ea63bfe152fa4e97272a47c7", null ],
    [ "PlaceInFile", "interface_conllu_visualiser_1_1_i_sentence.html#a02189f8293ed6736949f0336c2e60c21", null ],
    [ "Root", "interface_conllu_visualiser_1_1_i_sentence.html#ab9c312a033a4f171a94015ea0a67f102", null ],
    [ "Sent_id", "interface_conllu_visualiser_1_1_i_sentence.html#a99d1909a53dc5bcd2e0e907d165a4de8", null ],
    [ "Text_attribute", "interface_conllu_visualiser_1_1_i_sentence.html#ab322ebde512fe6a5617014e3a24130ed", null ]
];