var interface_conllu_visualiser_1_1_i_validator =
[
    [ "AddUsed", "interface_conllu_visualiser_1_1_i_validator.html#aeeaf2c1ff1e2dbf73f53aa3dd5cdeb40", null ],
    [ "MakeReadonly", "interface_conllu_visualiser_1_1_i_validator.html#a1716859aea4dac972c29afeaacb7c4b8", null ],
    [ "ValidateCell", "interface_conllu_visualiser_1_1_i_validator.html#a486152d1d13543877db0ee9c334f1f52", null ]
];