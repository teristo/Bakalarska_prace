var class_conllu_visualiser_1_1_conllu_file_loader =
[
    [ "ConlluFileLoader", "class_conllu_visualiser_1_1_conllu_file_loader.html#a65f4e920434b7eda38bbd338ed9dabf3", null ],
    [ "ReadFile", "class_conllu_visualiser_1_1_conllu_file_loader.html#a91ce789d2f764cff8ac5f70a544b9f71", null ]
];