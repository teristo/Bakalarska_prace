var class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic =
[
    [ "AddChild", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a803a8f2a226733d469a9aef5bd6fd36e", null ],
    [ "DeleteNode", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a29682190fb50e09e123e6efc5e724d79", null ],
    [ "GetMenu", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a61fa863624973d14e0c748292362f580", null ],
    [ "GetMenu", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#aa3bc34de2f4adf0df5925966e0884c42", null ],
    [ "GetMenu", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a67c45a771ad7d4a9f3beea7e0b5f3f75", null ],
    [ "RootMenu", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#af03a1c1d873ec4c35ea72108b11004c0", null ],
    [ "ShiftLeft", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a73741e884ccbffae8b428d3b08369c5c", null ],
    [ "ShiftRight", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a9c1a49ea589c2401f0364e65b4448a0e", null ],
    [ "ShowInfoAboutWord", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a52096922598cb8c42894aca76aa377f6", null ],
    [ "SplitNode", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#a1efaf332a3c8fe0ba3ccca55a9764055", null ],
    [ "SplitSentence", "class_graph_visualiser_1_1_basic_visualiser_1_1_get_menu_basic.html#ad89399261a1cebd2a077192ae4bce9fd", null ]
];