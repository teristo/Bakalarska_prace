var class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer =
[
    [ "EnhancedDesigner", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#a5fd8647c4e0b82d8b7522aa7a54f9e27", null ],
    [ "AddDepText", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#af41dfdae95b8d60695a58003d44ab982", null ],
    [ "DrawDepLine", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#afd67ffd7b4595d13b3febfc6bac754ad", null ],
    [ "DrawLines", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#ac4151978aca55c153d9932d7c6000302", null ],
    [ "DrawPoint", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#acb77a6180929eb582ef831bec16ab1f0", null ],
    [ "GetSiblingOrItself", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#af7ca0511d7d525253f4c314d614e108d", null ],
    [ "NewPoints", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#a6ac2c798bd138daadaf1070918354bc7", null ],
    [ "ShiftActive", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#a636431beef17838aeb39b30fbd2b7f41", null ],
    [ "Visualise", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#a61211a776ff6667b0b4a5f9c18891923", null ],
    [ "HeightOfLevel", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#a57674f3da49fed4f2e821e7259f7165d", null ],
    [ "PointCounter", "class_graph_visualiser_1_1_enhanced_visualiser_1_1_enhanced_designer.html#ac88be9ae38c8f1038a6b17706e9914ed", null ]
];