var class_conllu_visualiser_1_1_conllu_validator =
[
    [ "ConlluValidator", "class_conllu_visualiser_1_1_conllu_validator.html#a00a08f937e99c8caacfdce008508e91f", null ],
    [ "AddUsed", "class_conllu_visualiser_1_1_conllu_validator.html#a898e3e5a1c0b1530c93a916c8ad550d8", null ],
    [ "CancelValidation", "class_conllu_visualiser_1_1_conllu_validator.html#a18f0558e2428934f7f0e74e5b93c07e7", null ],
    [ "MakeReadonly", "class_conllu_visualiser_1_1_conllu_validator.html#aae2d4a4f779d923769cba6bf74ba4bb7", null ],
    [ "TryAddUsed", "class_conllu_visualiser_1_1_conllu_validator.html#a99c4324060f42df8b939db2f423da484", null ],
    [ "TryRemoveUsed", "class_conllu_visualiser_1_1_conllu_validator.html#aaa42238bc87b4be07f52e4c51b1f6d90", null ],
    [ "ValidateCell", "class_conllu_visualiser_1_1_conllu_validator.html#ab2300aa5b13adf86d13b78e77a08f01b", null ],
    [ "ValidateDeps", "class_conllu_visualiser_1_1_conllu_validator.html#a4bd756eaecb92ed79fa4315cf1828533", null ],
    [ "ValidateDictValue", "class_conllu_visualiser_1_1_conllu_validator.html#ae59d646ab513b3beda24e27ef5a8f40c", null ],
    [ "ValidateFormat", "class_conllu_visualiser_1_1_conllu_validator.html#ada054af4106fd79322464fe1673a81c1", null ],
    [ "ValidateHead", "class_conllu_visualiser_1_1_conllu_validator.html#aea2dd37487023988643dc3cf1762c203", null ],
    [ "ValidateSentenceRelations", "class_conllu_visualiser_1_1_conllu_validator.html#a4269281dc2daec732f4c3e446528c066", null ],
    [ "Sentence", "class_conllu_visualiser_1_1_conllu_validator.html#a5ce7e3e1aa943e37c681ac228d7ae8fd", null ],
    [ "UsedDeps", "class_conllu_visualiser_1_1_conllu_validator.html#a4b1dfeeffbf20f5a5baa45901376affc", null ],
    [ "UsedFeats", "class_conllu_visualiser_1_1_conllu_validator.html#ae44a10f69ca57900e086f99143ee0858", null ],
    [ "UsedMisc", "class_conllu_visualiser_1_1_conllu_validator.html#a78aff32ddee272d873ee01d4c438ae48", null ]
];