var class_conllu_visualiser_1_1_reader =
[
    [ "Reader", "class_conllu_visualiser_1_1_reader.html#a5603e125c5baf7642e505a828414c32f", null ],
    [ "Reader", "class_conllu_visualiser_1_1_reader.html#a6c9005b6bd45a396b38675280f4217a2", null ],
    [ "Dispose", "class_conllu_visualiser_1_1_reader.html#ac89d93ed36d819357ea1affe05c0ed1c", null ],
    [ "ReadLine", "class_conllu_visualiser_1_1_reader.html#acf983bb2c682b4dff545570bab4070db", null ],
    [ "EndOfFile", "class_conllu_visualiser_1_1_reader.html#a1950db85198847179a2ecab1f2816341", null ],
    [ "File", "class_conllu_visualiser_1_1_reader.html#adec04779da87eefc06023a0595023555", null ]
];