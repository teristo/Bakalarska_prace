var class_conllu_visualiser_1_1_sentence_info =
[
    [ "SentenceInfo", "class_conllu_visualiser_1_1_sentence_info.html#ac644874b90b78cf67c7fd4caeea2655c", null ],
    [ "AddRows", "class_conllu_visualiser_1_1_sentence_info.html#a91ad2d0c0620424453ab99486a29176e", null ],
    [ "ChangeText", "class_conllu_visualiser_1_1_sentence_info.html#ab490897ddd5e201e08832245ce6fd7b9", null ],
    [ "InitTable", "class_conllu_visualiser_1_1_sentence_info.html#acb0964165e66871c2261abe275d31c18", null ],
    [ "SaveChanges", "class_conllu_visualiser_1_1_sentence_info.html#aa85f7c704c931ce6b0cb310bb91f6e88", null ],
    [ "SaveToFile", "class_conllu_visualiser_1_1_sentence_info.html#abeafd05893de3d8aa9e593a913aa1dea", null ],
    [ "ShowInfo", "class_conllu_visualiser_1_1_sentence_info.html#a876e6ec3938f43f21961a010ac383398", null ],
    [ "ValidateCell", "class_conllu_visualiser_1_1_sentence_info.html#ac43956d28e584137ca802638d4eb86f2", null ],
    [ "Info", "class_conllu_visualiser_1_1_sentence_info.html#a6f854d96470d23318a2fefae7fbd41d8", null ],
    [ "Sent_id", "class_conllu_visualiser_1_1_sentence_info.html#aac43b9bd9afabe910e4875740612b0d0", null ],
    [ "Sentence", "class_conllu_visualiser_1_1_sentence_info.html#a66933931f7ddc07cd5b2acb10b8608e0", null ],
    [ "TableRoot", "class_conllu_visualiser_1_1_sentence_info.html#adc34043a3b92c36ee25dabc0d317bdb1", null ]
];