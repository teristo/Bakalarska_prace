var interface_graph_visualiser_1_1_i_designer =
[
    [ "DrawPoint", "interface_graph_visualiser_1_1_i_designer.html#af81f847a6c9693810cc4bd5ec94d1f8c", null ],
    [ "GetContextMenu", "interface_graph_visualiser_1_1_i_designer.html#ac6009bb28c268b6d721a33d1a20403ab", null ],
    [ "NewPoints", "interface_graph_visualiser_1_1_i_designer.html#a95dbbaf90652f4c7e5636549f6b78100", null ],
    [ "ShiftActive", "interface_graph_visualiser_1_1_i_designer.html#a0cefbc258f8c3397a4c1cb02ca499835", null ],
    [ "Visualise", "interface_graph_visualiser_1_1_i_designer.html#a7aeaec062ef6f64266d6f3ce6e620002", null ],
    [ "Schema", "interface_graph_visualiser_1_1_i_designer.html#aff8c8bc10e1a46a24c2009b8f90eb585", null ]
];