var class_conllu_visualiser_1_1_word =
[
    [ "Word", "class_conllu_visualiser_1_1_word.html#add8361a691b3554c8b13ab9e2de62afc", null ],
    [ "Accept", "class_conllu_visualiser_1_1_word.html#a64cdace10dfe240661a015498432cc81", null ],
    [ "CanStartNewSentence", "class_conllu_visualiser_1_1_word.html#a5e00f7bc2be1e4608c1c7674778c0dab", null ],
    [ "Delete", "class_conllu_visualiser_1_1_word.html#a72b404a747c5b9af90e9bc9268895cca", null ],
    [ "GetContextMenu", "class_conllu_visualiser_1_1_word.html#a29f21d8cf3ae1ef291ac19130e1dbebc", null ],
    [ "GetFormToSentence", "class_conllu_visualiser_1_1_word.html#af135329ce1af717f3f895482b22ce13c", null ],
    [ "GetWordBasicInfo", "class_conllu_visualiser_1_1_word.html#a5a29bf86c30c4b2fa413133365c858f9", null ],
    [ "GetWordPoint", "class_conllu_visualiser_1_1_word.html#a2bbcb33aac8e6b76179a764ea189ae87", null ],
    [ "RemoveChildEnhhanced", "class_conllu_visualiser_1_1_word.html#a512ba765ed52438a4b62de4adcbcaf57", null ],
    [ "SaveToFile", "class_conllu_visualiser_1_1_word.html#a1be8a6c2ea30b2e13c496f2ab419f1f2", null ],
    [ "ShiftId", "class_conllu_visualiser_1_1_word.html#a9c30a20fb147f75c03954f9b8a5524d4", null ],
    [ "ShowInfo", "class_conllu_visualiser_1_1_word.html#ab70b67594165c6d2bfee0263a741a711", null ],
    [ "Point", "class_conllu_visualiser_1_1_word.html#a4af5686adb3449864b26bcd2662f2f84", null ],
    [ "ChildrenEnhanced", "class_conllu_visualiser_1_1_word.html#a66b19593b8a1951aeacef5dbd8576fb7", null ],
    [ "Id", "class_conllu_visualiser_1_1_word.html#a2bc416872c14ce27cdfd74027b7ae5a7", null ],
    [ "Info", "class_conllu_visualiser_1_1_word.html#a1567e058a3b4854c53e97f315419fe09", null ],
    [ "IsActive", "class_conllu_visualiser_1_1_word.html#a7413d5c5fe3a2ce67340809841ba48dd", null ]
];