var class_conllu_visualiser_1_1_conllu_sentence_factory =
[
    [ "OneSentenceParts", "class_conllu_visualiser_1_1_conllu_sentence_factory_1_1_one_sentence_parts.html", "class_conllu_visualiser_1_1_conllu_sentence_factory_1_1_one_sentence_parts" ],
    [ "ConlluSentenceFactory", "class_conllu_visualiser_1_1_conllu_sentence_factory.html#aa52095064133d7e24e6eef647723dc39", null ],
    [ "GetSentence", "class_conllu_visualiser_1_1_conllu_sentence_factory.html#a217315ecb1f62b929f8f809fef2af81a", null ],
    [ "Reader", "class_conllu_visualiser_1_1_conllu_sentence_factory.html#ab71341c8a43948712ae621c7d645e991", null ]
];