var class_conllu_visualiser_1_1_program =
[
    [ "Main", "class_conllu_visualiser_1_1_program.html#a4fb6ca4fe7322bd6a11eff42f49b52ae", null ]
];