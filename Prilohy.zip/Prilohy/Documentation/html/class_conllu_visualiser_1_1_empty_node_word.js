var class_conllu_visualiser_1_1_empty_node_word =
[
    [ "EmptyNodeWord", "class_conllu_visualiser_1_1_empty_node_word.html#a07266c2dfaa15a4ca9271994a22a6e44", null ],
    [ "Accept", "class_conllu_visualiser_1_1_empty_node_word.html#a1dbe23bd921c9607dd5022cd37d3d1b6", null ],
    [ "CanStartNewSentence", "class_conllu_visualiser_1_1_empty_node_word.html#af8e0ce240852c54bf03262598de55113", null ],
    [ "Delete", "class_conllu_visualiser_1_1_empty_node_word.html#a63cb38e95e73f479ba085fc23ff61d7b", null ],
    [ "GetContextMenu", "class_conllu_visualiser_1_1_empty_node_word.html#a293ec4565c91d099d5c0641fa1b36afe", null ],
    [ "GetFormToSentence", "class_conllu_visualiser_1_1_empty_node_word.html#a2e89796706c08909dbab1e2834d4fbd5", null ],
    [ "ShiftId", "class_conllu_visualiser_1_1_empty_node_word.html#a7d0ddcea4e721b6b2c566e69743dc3ed", null ],
    [ "Swap", "class_conllu_visualiser_1_1_empty_node_word.html#a5bf46d195e74ff251f90c16be5500906", null ],
    [ "MainWord", "class_conllu_visualiser_1_1_empty_node_word.html#ab2b21b9e580cbba7b5dd97610bb26638", null ]
];