var annotated_dup =
[
    [ "ConlluVisualiser", "namespace_conllu_visualiser.html", "namespace_conllu_visualiser" ],
    [ "Finder", "namespace_finder.html", "namespace_finder" ],
    [ "GraphVisualiser", "namespace_graph_visualiser.html", "namespace_graph_visualiser" ]
];