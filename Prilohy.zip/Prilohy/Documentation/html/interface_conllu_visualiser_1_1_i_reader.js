var interface_conllu_visualiser_1_1_i_reader =
[
    [ "ReadLine", "interface_conllu_visualiser_1_1_i_reader.html#a00f44be9ed5fc44a1a6de1518d7c9342", null ],
    [ "EndOfFile", "interface_conllu_visualiser_1_1_i_reader.html#a70d8b967e50d16dfc00af73f5bee3e85", null ]
];