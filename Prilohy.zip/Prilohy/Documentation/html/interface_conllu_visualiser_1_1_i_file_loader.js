var interface_conllu_visualiser_1_1_i_file_loader =
[
    [ "LoadFile", "interface_conllu_visualiser_1_1_i_file_loader.html#a32d7bc8ecb8ce5c8e736d5a24c2f9608", null ]
];