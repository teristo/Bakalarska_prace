var class_conllu_visualiser_1_1_simple_file_loader =
[
    [ "SimpleFileLoader", "class_conllu_visualiser_1_1_simple_file_loader.html#adc0b3a658ea13551cc33e0d5e9fcb017", null ],
    [ "InformAboutLoading", "class_conllu_visualiser_1_1_simple_file_loader.html#ade0ffe34aca67315a87f6a660964c67e", null ],
    [ "LoadFile", "class_conllu_visualiser_1_1_simple_file_loader.html#a3c3c90895de6f8ba50deffe3c8e280aa", null ],
    [ "ReadFile", "class_conllu_visualiser_1_1_simple_file_loader.html#a87fdad11fe0d8a17b0016fd4ada8059d", null ],
    [ "MessagePanel", "class_conllu_visualiser_1_1_simple_file_loader.html#a31756938057f91a26921c857bcc7491b", null ]
];