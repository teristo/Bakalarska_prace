﻿using System.Drawing;
using System.Windows.Forms;

namespace SentenceVisualiser
{
    /// <summary>
    /// Loader that loads the file in CoNLL-U format and saves all the sentences to the list.
    /// </summary>
    class ConlluFileLoader : SimpleFileLoader, IFileLoader
    {
        /// <summary>
        /// Creates the CoNLL-U file loader.
        /// </summary>
        /// <param name="tp">The panel where it will be written the loading message to.</param>
        public ConlluFileLoader(Panel tp) : base(tp)
        {
        }

        /// <summary>
        /// Opens the open file dialog and loads the selected file in the CoNLL-U format.
        /// </summary>
        /// <param name="sentences">The list of sentences where the sentences from the file are saved to.</param>
        /// <returns>True if the file was succesfully loaded; otherwise, false.</returns>
        public override bool LoadFile(ListOfSentences sentences)
        {
            // Opens the dialog where the user can choose the file.
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                // Writes the loading message to the panel.
                InformAboutLoading();
                try
                {
                    // Reads the whole file and saves it to the list of sentences.
                    using (IReader reader = new Reader(dialog.FileName))
                    {
                        // Uses the ConlluSentenceFactory to create the sentences.
                        sentences.AddSentences(new ConlluSentencesFactory(reader));
                        return true;
                    }
                }
                catch
                {
                    // Notices the user that the file has a bad format.
                    MessageBox.Show("File is not in a CoNLL-U format.");
                    return false;
                }
            }
            // Clears the panel to be empty - no file was chosen.
            Graphics g = MessagePanel.CreateGraphics();
            g.Clear(Color.White);
            return true;
        }
    }
}
