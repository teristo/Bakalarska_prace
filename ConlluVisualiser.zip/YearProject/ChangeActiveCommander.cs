﻿namespace SentenceVisualiser
{
    /// <summary>
    /// Implements Commander design pattern.
    /// It is the mean how to change the active sentence or the active word inside the main form.
    /// Used when there is not necessary to have access to whole form.
    /// </summary>
    public class ChangeActiveCommander
    {
        /// <summary>
        /// The form that can be changed.
        /// </summary>
        private readonly Form1 MainForm;

        /// <summary>
        /// Creates the commander of the <paramref name="form"/>.
        /// </summary>
        /// <param name="form">The form that can be changed by this way.</param>
        public ChangeActiveCommander(Form1 form)
        {
            MainForm = form;
        }
        
        /// <summary>
        /// Changes the active word in the main form.
        /// </summary>
        /// <param name="word">The new active word.</param>
        public void ChangeActiveWord(IWord word)
        {
            MainForm.ChangeActiveWord(word);
        }

        /// <summary>
        /// Changes the active sentence in the main form.
        /// </summary>
        /// <param name="sentence">The new active sentence.</param>
        public void ChangeActiveSentence(ISentence sentence)
        {
            MainForm.ChangeActiveSentence(sentence);
        }

        /// <summary>
        /// Actualizes the visualised graph of the sentence.
        /// </summary>
        public void VisualiseNewGraph()
        {
            MainForm.VisualiseNewGraph();
        }
    }
}
